import { useEffect, useMemo, useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { X, MessageCircle, CreditCard, Copy, Check, Globe2, ShieldCheck } from "lucide-react";
import { cn } from "@/lib/utils";
import toothCoin from "@/assets/icons/badge-tooth.png";
import mcLogo from "@/assets/icons/mastercrown-logo.png";

/**
 * GHL "Bridge" Top-Up
 * - US users: Stripe checkout placeholder (coming soon).
 * - India / international users: WhatsApp deep-link with #BuyTokens<N> keyword
 *   + dynamic QR (each open generates a unique txn id so GHL can attribute the
 *   payment back to a specific user/pack via the inbound webhook).
 *
 * GHL workflow expects:
 *   Trigger: WhatsApp inbound message contains "#BuyTokens"
 *   The keyword carries pack size and txn id, e.g.  #BuyTokens100 txn:abc123
 */

// TODO(infra): swap placeholder for the live WhatsApp Business number
//   wired to the GHL location handling #BuyTokens.
const WA_NUMBER = "15555550100"; // E.164 without "+"

type Region = "US" | "IN";

const PACKS: { id: string; tokens: number; usd: number; label: string; badge?: string }[] = [
  { id: "100", tokens: 100, usd: 100, label: "Starter" },
  { id: "500", tokens: 500, usd: 450, label: "Practice", badge: "10% OFF" },
  { id: "1200", tokens: 1200, usd: 1000, label: "Clinic", badge: "BEST VALUE" },
];

function makeTxnId() {
  return Math.random().toString(36).slice(2, 8) + Date.now().toString(36).slice(-4);
}

function detectRegion(): Region {
  if (typeof navigator === "undefined") return "US";
  const lang = (navigator.language || "").toLowerCase();
  const tz = Intl.DateTimeFormat().resolvedOptions().timeZone || "";
  if (lang.endsWith("-in") || tz.includes("Kolkata") || tz.includes("Calcutta")) return "IN";
  return "US";
}

function waLink(packId: string, txnId: string) {
  const text = `#BuyTokens${packId} txn:${txnId}`;
  return `https://wa.me/${WA_NUMBER}?text=${encodeURIComponent(text)}`;
}

function qrSrc(url: string) {
  // Lightweight, no-dep QR. Production should self-host or swap for a generator.
  return `https://api.qrserver.com/v1/create-qr-code/?size=240x240&margin=8&data=${encodeURIComponent(url)}`;
}

export function TopUpModal({ open, onClose }: { open: boolean; onClose: () => void }) {
  const [region, setRegion] = useState<Region>("US");
  const [selected, setSelected] = useState<string>("500");
  const [txnId, setTxnId] = useState<string>(() => makeTxnId());
  const [copied, setCopied] = useState(false);

  useEffect(() => {
    if (open) {
      setRegion(detectRegion());
      setTxnId(makeTxnId());
    }
  }, [open]);

  const pack = PACKS.find(p => p.id === selected) ?? PACKS[1];
  const link = useMemo(() => waLink(pack.id, txnId), [pack.id, txnId]);

  const handleCopy = async () => {
    await navigator.clipboard.writeText(link);
    setCopied(true);
    setTimeout(() => setCopied(false), 1500);
  };

  return (
    <AnimatePresence>
      {open && (
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-sm"
          onClick={onClose}
        >
          <motion.div
            initial={{ scale: 0.95, y: 20, opacity: 0 }}
            animate={{ scale: 1, y: 0, opacity: 1 }}
            exit={{ scale: 0.95, y: 20, opacity: 0 }}
            transition={{ type: "spring", damping: 22, stiffness: 240 }}
            onClick={(e) => e.stopPropagation()}
            className="relative w-full max-w-lg rounded-3xl bg-gradient-to-b from-white via-white to-[#f7f1e6] border border-[var(--mc-brown)]/15 shadow-[0_40px_80px_-30px_rgba(40,30,20,0.6)] overflow-hidden"
          >
            {/* Header — Vault, navy + gold */}
            <div className="flex items-center gap-3 px-6 pt-6 pb-4 border-b border-[#fde047]/25 bg-gradient-to-b from-[#0b1437] to-[#050a1f]">
              <img src={mcLogo} alt="MasterCrown" className="h-10 w-10 aspect-square rounded-full ring-2 ring-[#fde047]/50 drop-shadow-[0_2px_10px_rgba(253,224,71,0.4)]" />
              <div className="flex-1 min-w-0">
                <p className="text-[10px] uppercase tracking-[0.24em] text-[#fde047]/70 font-bold">Vault</p>
                <p className="text-[15px] font-semibold text-white leading-tight">Purchase <span className="mastercoin-text">MasterCredits</span></p>
              </div>
              <button onClick={onClose} className="p-1.5 rounded-full hover:bg-white/10 text-[#fde047]/70 hover:text-[#fde047]">
                <X className="w-4 h-4" />
              </button>
            </div>

            {/* Region toggle */}
            <div className="px-6 pt-4">
              <div className="inline-flex items-center gap-1 p-1 rounded-full bg-[var(--mc-brown)]/8 border border-[var(--mc-brown)]/15 text-[11px]">
                <Globe2 className="w-3.5 h-3.5 ml-2 text-[var(--mc-brown)]/60" />
                {(["US", "IN"] as Region[]).map(r => (
                  <button
                    key={r}
                    onClick={() => setRegion(r)}
                    className={cn(
                      "px-3 py-1 rounded-full font-bold uppercase tracking-wider transition-colors",
                      region === r ? "bg-[var(--mc-brown)] text-white" : "text-[var(--mc-brown)]/60"
                    )}
                  >
                    {r === "US" ? "United States" : "India / Intl."}
                  </button>
                ))}
              </div>
            </div>

            {/* Pack picker */}
            <div className="px-6 pt-4 grid grid-cols-3 gap-2">
              {PACKS.map(p => {
                const active = p.id === selected;
                return (
                  <button
                    key={p.id}
                    onClick={() => { setSelected(p.id); setTxnId(makeTxnId()); }}
                    className={cn(
                      "relative rounded-2xl border-2 p-3 text-left transition-all",
                      active
                        ? "border-[var(--mc-brown)] bg-white shadow-md"
                        : "border-[var(--mc-brown)]/15 bg-white/50 hover:border-[var(--mc-brown)]/30"
                    )}
                  >
                    {p.badge && (
                      <span className="absolute -top-2 left-2 text-[8.5px] font-bold tracking-widest bg-[var(--mc-gold)] text-[var(--mc-brown)] px-1.5 py-0.5 rounded">
                        {p.badge}
                      </span>
                    )}
                    <div className="flex items-center gap-1.5">
                      <img src={toothCoin} alt="" className="h-5 w-5" />
                      <p className="text-[16px] font-bold text-[var(--mc-brown)] tabular-nums leading-none">{p.tokens}</p>
                    </div>
                    <p className="text-[10px] uppercase tracking-wider text-[var(--mc-brown)]/55 font-semibold mt-1">{p.label}</p>
                    <p className="text-[12px] font-bold text-[var(--mc-brown)] mt-0.5">${p.usd}</p>
                  </button>
                );
              })}
            </div>

            {/* Region-specific checkout */}
            <div className="px-6 py-5">
              {region === "US" ? (
                <div className="rounded-2xl border border-[var(--mc-brown)]/15 bg-white/70 p-5 text-center space-y-3">
                  <CreditCard className="w-6 h-6 mx-auto text-[var(--mc-brown)]/60" />
                  <p className="text-[13px] font-semibold text-[var(--mc-brown)]">Card checkout — coming online</p>
                  <p className="text-[11px] text-[var(--mc-brown)]/65 leading-snug">
                    Stripe is being connected for US customers. MasterCredits credit instantly on payment confirmation.
                  </p>
                  <button
                    disabled
                    className="w-full rounded-xl bg-[var(--mc-brown)]/30 text-white py-2.5 text-[12px] font-bold uppercase tracking-wider cursor-not-allowed"
                  >
                    Purchase {pack.tokens} MasterCredits — ${pack.usd}
                  </button>
                </div>
              ) : (
                <div className="space-y-4">
                  <div className="flex gap-4 items-center rounded-2xl border border-[#25D366]/30 bg-gradient-to-br from-[#25D366]/8 to-white p-4">
                    <img
                      src={qrSrc(link)}
                      alt={`Scan to purchase ${pack.tokens} MasterCredits`}
                      className="w-28 h-28 rounded-lg border border-[var(--mc-brown)]/15 bg-white shrink-0"
                    />
                    <div className="min-w-0 flex-1 space-y-1.5">
                      <p className="text-[10px] uppercase tracking-[0.18em] font-bold text-[#128C7E]">
                        Scan · Pay via WhatsApp
                      </p>
                      <p className="text-[12px] text-[var(--mc-brown)]/75 leading-snug">
                        Opens WhatsApp pre-filled with{" "}
                        <code className="px-1 py-0.5 rounded bg-black/5 font-mono text-[11px]">#BuyTokens{pack.id}</code>{" "}
                        — our agent replies with a Coinbase / UPI link.
                      </p>
                      <p className="text-[9.5px] font-mono text-[var(--mc-brown)]/45">txn: {txnId}</p>
                    </div>
                  </div>

                  <div className="grid grid-cols-2 gap-2">
                    <a
                      href={link}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="flex items-center justify-center gap-2 rounded-xl bg-[#25D366] hover:bg-[#1ebe5d] text-white py-2.5 text-[12px] font-bold uppercase tracking-wider transition-colors shadow-lg shadow-[#25D366]/30"
                    >
                      <MessageCircle className="w-4 h-4" />
                      Open WhatsApp
                    </a>
                    <button
                      onClick={handleCopy}
                      className="flex items-center justify-center gap-2 rounded-xl border-2 border-[var(--mc-brown)]/20 bg-white hover:border-[var(--mc-brown)]/40 text-[var(--mc-brown)] py-2.5 text-[12px] font-bold uppercase tracking-wider transition-colors"
                    >
                      {copied ? <Check className="w-4 h-4" /> : <Copy className="w-4 h-4" />}
                      {copied ? "Copied" : "Copy Link"}
                    </button>
                  </div>

                  <div className="flex items-start gap-2 rounded-lg bg-[var(--mc-gold)]/10 border border-[var(--mc-gold)]/30 p-2.5">
                    <ShieldCheck className="w-3.5 h-3.5 text-[var(--mc-gold)] mt-0.5 shrink-0" />
                    <p className="text-[10px] text-[var(--mc-brown)]/75 leading-snug">
                      Pay with USDC (Coinbase Commerce) or UPI — zero international card fees.
                      Your <span className="font-bold">MasterCredit</span> balance updates here the moment payment confirms.
                    </p>
                  </div>
                </div>
              )}
            </div>
            <div className="px-6 pb-4 -mt-2">
              <p className="text-center font-mono-tech text-[9px] uppercase tracking-[0.24em] text-[var(--mc-brown)]/45">
                Vault · vault.mastercrown.ai
              </p>
            </div>
          </motion.div>
        </motion.div>
      )}
    </AnimatePresence>
  );
}
