                <p className="mt-1 text-[11px] font-light leading-snug text-white/70">
                  Purchasing activates once secure payments are connected.
                </p>
              </div>

              <div className="relative flex-1 flex flex-col justify-end gap-3">
                <button
                  type="button"
                  onClick={handleTopUp}
                  className="w-full rounded-lg bg-gradient-to-b from-[#fde047] to-[#ca8a04] hover:from-[#fef08a] hover:to-[#eab308] px-2 py-3 text-[10px] font-bold uppercase tracking-[0.2em] text-[#0b1437] transition-colors shadow-[0_8px_20px_-8px_rgba(253,224,71,0.6)]"
                >
                  Purchase MasterCredits ↗
                </button>

                <button
                  type="button"
                  onClick={handleTopUp}
                  className="w-full rounded-lg border border-[#fde047]/40 bg-white/5 hover:bg-[#fde047]/10 px-2 py-2.5 text-[10px] font-bold uppercase tracking-[0.2em] text-[#fde047] transition-colors"
                >
                  Exchange MasterCredits for Designs
                </button>
              </div>

              <div className="relative rounded-lg bg-[#fde047]/8 border border-[#fde047]/25 p-2">
                <p className="text-[9.5px] text-[#fde047]/85 leading-snug">
                  ⚡ <MasterCoin plural className="text-[9.5px]" /> auto-deduct on case submit. No surprise charges.
                </p>
              </div>

              <p className="relative text-center text-[8.5px] font-mono-tech uppercase tracking-[0.22em] text-[#fde047]/40 pt-1 border-t border-[#fde047]/15">
                vault.masterstl.ai
              </p>
            </aside>
          )}

          {/* RIGHT — Main workflow card */}
          <AnimatePresence mode="wait">
          <motion.div
            key={`${category}-${workflow}`}
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -10 }}
            className="lg:row-span-2 rounded-3xl bg-white/70 backdrop-blur-[20px] border border-[var(--mc-brown)]/30 p-6 md:p-8 space-y-5 shadow-[0_30px_60px_-30px_rgba(40,30,20,0.4)]"
          >
            {(category === "crowns" || category === "bridges" || category === "copings") && workflow === "configure" && (
              <>
                <div className="pb-2 border-b border-[var(--mc-brown)]/10">
                  <p className="text-[10px] uppercase tracking-[0.22em] text-[var(--mc-gold)] font-bold">Design Preview</p>
                  <h2 className="mt-1 text-xl font-bold text-[var(--mc-brown)] tracking-tight flex items-center gap-2">
                    {(() => { const I = activeIcon; return <I className="w-5 h-5" />; })()}
                    {PREFS[category].title}
                  </h2>
                  <p className="text-[11px] text-[var(--mc-brown)]/60 mt-1">
                    Tile preview. Click a value below each illustration to change it.
                  </p>
                </div>

                {/* Defaults */}
                <div className="rounded-xl bg-white/55 border border-[var(--mc-brown)]/25 p-5">
                  <p className="text-[13px] font-semibold text-[var(--mc-brown)] tracking-tight mb-4 flex items-center gap-2">
                    <span className="h-1.5 w-1.5 rounded-full bg-[var(--mc-gold)]" />
                    Standard Design Parameters
                  </p>
                  <div className="grid grid-cols-2 md:grid-cols-4 gap-5">
                    {DEFAULTS.map(d => (
                      <div key={d.label} className="text-center">
                        <p className="text-[10px] text-[var(--mc-brown)]/50 mb-0.5">{d.label}</p>
                        <p className="text-sm font-semibold text-[var(--mc-brown)]">{d.value}</p>
                      </div>
                    ))}
                  </div>
                </div>

                <div>
                  <p className="text-center text-[10px] uppercase tracking-[0.22em] text-[var(--mc-brown)]/50 font-semibold mb-3">
                    {PREFS[category].sectionLabel}
                  </p>
                  <div className="grid grid-cols-2 md:grid-cols-4 gap-5">
                    {PREFS[category].fields.map(f => (
                      <DesignPrefTile
                        key={f.key}
                        label={f.label}
                        options={f.options}
                        value={prefs[category][f.key] ?? f.options[0]}
                        onChange={(v) => setPref(category, f.key, v)}
                        icon={activeIcon}
                      />
                    ))}
                  </div>
                </div>

                <div className="space-y-1.5">
                  <Label className="text-[var(--mc-brown)] text-sm font-semibold">Select Tooth Numbers *</Label>
                  <div className="bg-white/55 backdrop-blur-sm border border-[var(--mc-brown)]/25 rounded-2xl p-4">
                    <MasterToothChart selectedTeeth={selectedTeeth} onToothClick={handleToothClick} />
                  </div>
                  {selectedTeeth.length > 0 && (
                    <p className="text-xs text-[var(--mc-brown)]/70">
                      {selectedTeeth.length} unit(s) · <span className="text-[var(--mc-brown)] font-semibold">${selectedTeeth.length * unitPrice}</span>
                    </p>
                  )}
                </div>

                <div className="space-y-1.5">
                  <Label className="text-[var(--mc-brown)] text-sm font-semibold">Upload Scan *</Label>
                  <label className={cn(
                    "flex items-center gap-3 p-4 rounded-xl border-2 border-dashed cursor-pointer transition-all duration-300",
                    scanFile ? "border-[var(--mc-brown)]/50 bg-[var(--mc-brown)]/5" : "border-[var(--mc-brown)]/20 hover:border-[var(--mc-brown)]/40 bg-white/50"
                  )}>
                    <div className={cn("w-10 h-10 rounded-full flex items-center justify-center shrink-0", scanFile ? "bg-[var(--mc-brown)]/15" : "bg-white/60")}>
                      <Upload className={cn("w-4 h-4", scanFile ? "text-[var(--mc-brown)]" : "text-[var(--mc-brown)]/40")} />
                    </div>
                    <div className="min-w-0">
                      <span className={cn("text-xs font-medium block truncate", scanFile ? "text-[var(--mc-brown)]" : "text-[var(--mc-brown)]/60")}>
                        {scanFile ? scanFile.name : "Click to upload"}
                      </span>
                      <p className="text-[10px] text-[var(--mc-brown)]/40">STL, PLY, OBJ, ZIP</p>
                    </div>
                    <input type="file" accept=".stl,.ply,.zip,.obj,.dcm" className="hidden" onChange={e => { if (e.target.files?.[0]) setScanFile(e.target.files[0]); }} />
                  </label>
                </div>

                <div className="space-y-2 rounded-xl bg-white/55 border border-[var(--mc-brown)]/25 p-3">
                  <div className="flex items-center gap-2 text-[var(--mc-brown)]">
                    <Ruler className="w-3.5 h-3.5" />
                    <span className="text-xs font-semibold">Better Results (Optional)</span>
                  </div>
                  <div className="grid grid-cols-2 gap-3">
                    <Input type="number" step="0.5" placeholder="Central length (mm)" value={centralLength} onChange={e => setCentralLength(e.target.value)}
                      className="bg-white/70 border-[var(--mc-brown)]/15 text-[var(--mc-brown)] text-xs placeholder:text-[var(--mc-brown)]/30" />
                    <Input type="number" step="0.5" placeholder="Canine length (mm)" value={canineLength} onChange={e => setCanineLength(e.target.value)}
                      className="bg-white/70 border-[var(--mc-brown)]/15 text-[var(--mc-brown)] text-xs placeholder:text-[var(--mc-brown)]/30" />
                  </div>
                </div>

                <div className="space-y-1.5">
                  <Label className="text-[var(--mc-brown)] text-sm font-semibold">Notes (Optional)</Label>
                  <Textarea placeholder="Special instructions…" value={notes} onChange={e => setNotes(e.target.value)} rows={2}
                    className="bg-white/70 border-[var(--mc-brown)]/15 text-[var(--mc-brown)] placeholder:text-[var(--mc-brown)]/35 min-h-[60px]" />
                </div>

                <div className="rounded-xl bg-white/55 border border-[var(--mc-brown)]/25 px-4 py-2.5">
                  <p className="text-[11px] text-[var(--mc-brown)]/75 leading-relaxed">
                    <strong>Abandonment Policy:</strong> If you do not accept or reject within 24 hours, <strong>${ABANDON_FEE}/unit</strong> minimum will be charged.
                  </p>
                </div>

                <div className="flex items-center justify-between pt-4 border-t border-[var(--mc-brown)]/10">
                  <div>
                    <p className="text-2xl font-bold text-[var(--mc-brown)]">${totalPrice}</p>
                    <p className="text-[11px] text-[var(--mc-brown)]/60">{selectedTeeth.length} unit(s) × ${unitPrice}/unit</p>
                  </div>
                  <Button
                    onClick={handleSubmit}
                    disabled={submitting || selectedTeeth.length === 0}
                    size="lg"
                    className="bg-[var(--mc-brown)] hover:bg-[var(--mc-brown)]/90 text-white gap-2 px-8 shadow-lg"
                  >
                    <Send className="w-4 h-4" />
                    Submit for Design
                  </Button>
                </div>
              </>
            )}

            {workflow === "processing" && (
              <div className="text-center py-16 space-y-6">
                <motion.div animate={{ rotate: 360 }} transition={{ repeat: Infinity, duration: 2, ease: "linear" }} className="inline-block">
                  <Loader2 className="w-12 h-12 text-[var(--mc-brown)]" />
                </motion.div>
                <div>
                  <h3 className="text-xl font-bold text-[var(--mc-brown)] mb-1">MasterCrown is Designing…</h3>
                  <p className="text-sm text-[var(--mc-brown)]/60">AI is generating your STL files. This usually takes under 5 minutes.</p>
                </div>
                <div className="max-w-xs mx-auto">
                  <div className="h-1.5 bg-[var(--mc-brown)]/15 rounded-full overflow-hidden">
                    <motion.div className="h-full bg-[var(--mc-brown)] rounded-full" initial={{ width: "0%" }} animate={{ width: "90%" }} transition={{ duration: 3.5, ease: "easeOut" }} />
                  </div>
                </div>
              </div>
            )}

            {workflow === "review" && (
              <div className="space-y-5">
                <div className="pb-2 border-b border-[var(--mc-brown)]/10">
                  <h2 className="text-xl font-bold text-[var(--mc-brown)] tracking-tight flex items-center gap-2">
                    <CheckCircle2 className="w-5 h-5 text-emerald-600" />
                    Design Ready — Review &amp; Approve
                  </h2>
                  <p className="text-xs text-[var(--mc-brown)]/60 mt-1">
                    {selectedTeeth.length} unit(s) · Teeth #{[...selectedTeeth].sort((a, b) => a - b).join(", ")} · Style: {style} · Contact: {contactShape}
                  </p>
                </div>

                <div className="rounded-2xl border border-[var(--mc-brown)]/15 bg-white/60 h-64 flex items-center justify-center">
                  <p className="text-sm text-[var(--mc-brown)]/50">3D STL preview placeholder</p>
                </div>

                <div className="grid grid-cols-2 gap-3 text-center">
                  <div className="rounded-xl bg-white/60 border border-[var(--mc-brown)]/10 p-3">
                    <p className="text-[10px] text-[var(--mc-brown)]/50">Style</p>
                    <p className="text-sm font-bold text-[var(--mc-brown)]">{style}</p>
                  </div>
                  <div className="rounded-xl bg-white/60 border border-[var(--mc-brown)]/10 p-3">
                    <p className="text-[10px] text-[var(--mc-brown)]/50">Contact Shape</p>
                    <p className="text-sm font-bold text-[var(--mc-brown)]">{contactShape}</p>
                  </div>
                </div>

                <div className="flex items-center justify-between pt-4 border-t border-[var(--mc-brown)]/10">
                  <div>
                    <p className="text-2xl font-bold text-[var(--mc-brown)]">${totalPrice}</p>
                    <p className="text-[11px] text-[var(--mc-brown)]/60">Charged upon approval</p>
                  </div>
                  <div className="flex gap-3">
                    <Button onClick={handleReject} variant="outline" size="lg" className="border-[var(--mc-brown)]/30 text-[var(--mc-brown)] hover:bg-[var(--mc-brown)]/10 gap-2">
                      <XCircle className="w-4 h-4" />
                      Reject
                    </Button>
                    <Button onClick={handleApprove} size="lg" className="bg-emerald-600 hover:bg-emerald-500 text-white gap-2 px-8 shadow-lg">
                      <CheckCircle2 className="w-4 h-4" />
                      Approve &amp; Pay ${totalPrice}
                    </Button>
                  </div>
                </div>
              </div>
            )}

          </motion.div>
        </AnimatePresence>
        </div>
      </div>
      <TopUpModal open={topUpOpen} onClose={() => setTopUpOpen(false)} />
    </main>
  );
}
