Part 3 of 3 — MasterCrown App
Contains:
- mastercrown-app.part3.tsx (lines 501-736)
- TopUpModal.tsx (src/components/mastercrown/)
To reassemble: cat part1 part2 part3 > mastercrown-app.tsx
