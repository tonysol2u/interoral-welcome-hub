import { motion } from "framer-motion";
import { ShieldCheck, Crosshair } from "lucide-react";

const PILLARS = [
  {
    icon: ShieldCheck,
    eyebrow: "Book Smart Intelligence",
    title: "The Clinical Audit",
    body:
      "Every design is cross-referenced against a massive library of clinical literature and morphology standards. Book Smart doesn't just draw a tooth — it validates occlusion and margin integrity before you ever see the file.",
  },
  {
    icon: Crosshair,
    eyebrow: "Certified Geometry",
    title: "Zero-Error Precision",
    body:
      "Others offer 'express.' We offer certified. Sub-millimeter geometry, signed off by the engine, so the first fit is the final fit. That is what you're paying for — and why we charge more.",
  },
];

export function ValuePillars() {
  return (
    <section className="relative z-20 px-6 pb-20 pt-4 md:px-14 md:pb-28">
      <div className="mx-auto max-w-5xl">
        {/* Section heading */}
        <motion.div
          initial={{ opacity: 0, y: 16 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true, amount: 0.4 }}
          transition={{ duration: 0.6, ease: [0.16, 1, 0.3, 1] }}
          className="mb-10 text-center md:mb-14"
        >
          <p className="mc-track font-mono-tech text-[10px] uppercase tracking-[0.3em] text-[var(--mc-blue)]">
            Why MasterCrown Costs More
          </p>
          <h2
            className="mt-3 font-display font-light tracking-[-0.03em] text-[var(--mc-brown)]"
            style={{ fontSize: "clamp(24px, 3.6vw, 40px)", lineHeight: 1.1 }}
          >
            You aren't buying a design.
            <br className="hidden md:block" />{" "}
            <span className="italic text-[var(--mc-brown-soft)]">You're buying clinical intelligence.</span>
          </h2>
          <p className="mx-auto mt-4 max-w-xl text-[13px] font-light leading-relaxed text-[var(--mc-brown)]/75">
            Three pillars separate MasterCrown from every other "AI design" service on the market.
          </p>
        </motion.div>

        {/* Pillar cards */}
        <div className="mx-auto grid max-w-3xl grid-cols-1 gap-5 md:grid-cols-2 md:gap-6">
          {PILLARS.map((p, i) => (
            <motion.article
              key={p.title}
              initial={{ opacity: 0, y: 24 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true, amount: 0.3 }}
              transition={{ duration: 0.6, delay: i * 0.1, ease: [0.16, 1, 0.3, 1] }}
              whileHover={{ y: -4 }}
              className="group relative overflow-hidden rounded-3xl border border-[var(--mc-brown)]/25 bg-white/65 p-6 backdrop-blur-[14px] shadow-[0_30px_60px_-30px_rgba(40,30,20,0.4)] transition-all hover:border-[var(--mc-brown)]/45 hover:bg-white/80"
            >
              {/* gold corner accent */}
              <div
                aria-hidden
                className="pointer-events-none absolute -right-12 -top-12 h-32 w-32 rounded-full opacity-60 blur-2xl transition-opacity group-hover:opacity-100"
                style={{
                  background:
                    "radial-gradient(circle, rgba(217,164,65,0.45) 0%, rgba(217,164,65,0) 70%)",
                }}
              />

              <div className="relative">
                <div className="mb-4 inline-flex h-11 w-11 items-center justify-center rounded-xl border border-[var(--mc-gold)]/40 bg-gradient-to-br from-[var(--mc-gold)]/25 to-[var(--mc-brown)]/10">
                  <p.icon className="h-5 w-5 text-[var(--mc-brown)]" strokeWidth={1.5} />
                </div>

                <p className="mc-track font-mono-tech text-[9.5px] uppercase tracking-[0.22em] text-[var(--mc-blue)]">
                  {p.eyebrow}
                </p>
                <h3 className="mt-1 font-display text-[20px] font-semibold tracking-tight text-[var(--mc-brown)] md:text-[22px]">
                  {p.title}
                </h3>
                <p className="mt-3 text-[13px] font-light leading-[1.6] text-[var(--mc-brown)]/75">
                  {p.body}
                </p>
              </div>
            </motion.article>
          ))}
        </div>

        {/* Closing line */}
        <motion.p
          initial={{ opacity: 0 }}
          whileInView={{ opacity: 1 }}
          viewport={{ once: true }}
          transition={{ duration: 0.8, delay: 0.4 }}
          className="mx-auto mt-10 max-w-2xl text-center text-[12px] font-light italic leading-relaxed text-[var(--mc-brown-soft)] md:text-[13px]"
        >
          "We don't compete on speed. We compete on the peace of mind that the
          first fit is the final fit." — MasterCrown Engineering
        </motion.p>
      </div>
    </section>
  );
}
