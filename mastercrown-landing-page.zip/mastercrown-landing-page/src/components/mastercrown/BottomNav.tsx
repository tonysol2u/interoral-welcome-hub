import { Link } from "@tanstack/react-router";

export function BottomNav() {
  return (
    <nav
      className="fixed bottom-4 left-1/2 z-40 -translate-x-1/2 px-4"
      aria-label="Primary"
    >
      <div
        className="flex items-center gap-3 border border-[var(--mc-line)] bg-white/85 px-4 py-2 shadow-[0_20px_50px_-20px_rgba(40,30,20,0.4)] backdrop-blur-md md:gap-5 md:px-6 md:py-2.5"
        style={{ borderRadius: "999px" }}
      >
        <Link
          to="/"
          className="mc-track font-mono-tech text-[10px] text-[var(--mc-brown)] hover:text-[var(--mc-brown-soft)]"
        >
          MASTERCROWN.AI
        </Link>
        <span className="hidden h-4 w-px bg-[var(--mc-line)] md:block" />
        <Link
          to="/mastercrown-app"
          className="mc-track font-mono-tech text-[10px] text-[var(--mc-brown)] hover:text-[var(--mc-brown-soft)]"
        >
          APP
        </Link>
        <span className="hidden h-4 w-px bg-[var(--mc-line)] md:block" />
        <Link
          to="/essentials"
          className="mc-track font-mono-tech text-[10px] text-[var(--mc-brown)] hover:text-[var(--mc-brown-soft)]"
        >
          ESSENTIALS
        </Link>
        <span className="hidden h-4 w-px bg-[var(--mc-line)] md:block" />
        <Link
          to="/surgical-guides"
          className="mc-track font-mono-tech text-[10px] text-[var(--mc-brown)] hover:text-[var(--mc-brown-soft)]"
        >
          GUIDES
        </Link>
        <span className="hidden h-4 w-px bg-[var(--mc-line)] md:block" />
        <Link
          to="/mastercoin"
          className="mc-tile-sm inline-flex items-center justify-center gap-2 px-5 py-2.5 text-[11px] mc-track uppercase font-medium min-w-[160px] bg-[#0b1437] text-[#fde047] border border-[#fde047]/50 hover:bg-[#050a1f] transition-colors"
        >
          Buy Your Credits
        </Link>
      </div>
    </nav>
  );
}
