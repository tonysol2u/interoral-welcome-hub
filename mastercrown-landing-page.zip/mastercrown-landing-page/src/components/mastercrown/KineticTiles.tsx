import { motion } from "framer-motion";
import tmjCondyle from "@/assets/science/tmj-condyle.jpg";
import occlusionHeatmap from "@/assets/science/occlusion-heatmap.jpg";
import crownWireframe from "@/assets/science/crown-wireframe.jpg";

type Shape = "oval" | "round";

interface TileSpec {
  id: string;
  code: string;
  header: string;
  subtitle: string;
  body: string;
  shape: Shape;
  video?: string;
  image?: string;
  caption?: string;
  delay?: number;
}

const TILES: TileSpec[] = [
  {
    id: "01",
    code: "MC-01",
    header: "VERIFIED ANATOMY",
    subtitle: "The Bio-Mechanical Law",
    body:
      "Every design begins with the patient's own condylar movement, joint translation, and protrusive excursions — so the crown is engineered to how the jaw actually moves, not just to a static scan.",
    shape: "round",
    image: tmjCondyle,
    caption: "Verified Anatomy",
    delay: 0,
  },
  {
    id: "02",
    code: "MC-02",
    header: "PRECISION OCCLUSION",
    subtitle: "The Perfect Fit",
    body:
      "Contact points are calculated and balanced to the micron across every cusp and fossa. The crown arrives chair-ready — no grinding, no guesswork, no compromise on the patient's bite.",
    shape: "oval",
    image: occlusionHeatmap,
    caption: "Precision Occlusion",
    delay: 0.05,
  },
  {
    id: "03",
    code: "MC-03",
    header: "HIGH-FIDELITY OUTPUT",
    subtitle: "The Signature Output",
    body:
      "Margin integrity, axial wall geometry, and cement space are validated against your specific mill or printer. This is your high-fidelity blueprint — production-ready, signed off, and ready for the mill.",
    shape: "round",
    image: crownWireframe,
    caption: "High-Fidelity Output",
    delay: 0.1,
  },
];

const shapeRadius: Record<Shape, string> = {
  oval: "120px",
  round: "9999px",
};

function MediaTile({ spec }: { spec: TileSpec }) {
  const isRound = spec.shape === "round";
  return (
    <div className="flex shrink-0 flex-col items-center gap-3">
      <div
        className={`relative overflow-hidden bg-white shadow-[0_30px_60px_-30px_rgba(40,30,20,0.55),inset_0_0_0_1px_rgba(40,30,20,0.25)] ${
          isRound ? "aspect-square w-[150px] md:w-[190px]" : "aspect-[5/3] w-[200px] md:w-[260px]"
        }`}
        style={{ borderRadius: shapeRadius[spec.shape] }}
      >
        {spec.image ? (
          <img src={spec.image} alt={spec.header} loading="lazy" className="h-full w-full object-cover" />
        ) : spec.video ? (
          <video
            className="h-full w-full object-cover"
            autoPlay
            muted
            loop
            playsInline
          >
            <source src={spec.video} type="video/mp4" />
          </video>
        ) : null}
        <div
          className="pointer-events-none absolute inset-0 ring-1 ring-[var(--mc-brown)]/30"
          style={{ borderRadius: shapeRadius[spec.shape] }}
        />
      </div>
      {spec.caption && (
        <span className="mc-track font-mono-tech text-[9px] text-[var(--mc-brown-soft)]">
          {spec.caption}
        </span>
      )}
    </div>
  );
}

function Tile({ spec, index }: { spec: TileSpec; index: number }) {
  const reverse = index % 2 === 1;
  return (
    <motion.div
      initial={{ opacity: 0, scale: 0.85, y: 60, filter: "blur(6px)" }}
      whileInView={{ opacity: 1, scale: 1, y: 0, filter: "blur(0px)" }}
      viewport={{ once: false, amount: 0.3 }}
      transition={{
        duration: 0.85,
        delay: spec.delay,
        ease: [0.16, 1, 0.3, 1],
        scale: { type: "spring", stiffness: 220, damping: 18 },
      }}
      whileHover={{
        scale: 1.06,
        y: -10,
        transition: { duration: 0.3, ease: [0.16, 1, 0.3, 1] },
      }}
      className={`group flex flex-col items-center gap-8 md:gap-12 ${
        reverse ? "md:flex-row-reverse" : "md:flex-row"
      }`}
    >
      <MediaTile spec={spec} />

      <div className="flex-1 text-center md:text-left">
        <span className="mc-track font-mono-tech text-[10px] text-[var(--mc-cool-grey-ink)]">
          {spec.code} · 4K
        </span>
        <h3 className="mt-2 font-display text-[26px] font-black leading-[1.05] tracking-[-0.01em] text-[var(--mc-brown)] md:text-[34px]">
          {spec.header}
          <span className="ml-2 align-middle text-[14px] font-light tracking-[0.05em] text-[var(--mc-brown-soft)] md:text-[16px]">
            ({spec.subtitle})
          </span>
        </h3>
        <p className="mt-4 max-w-xl text-[14px] font-light leading-[1.6] text-[var(--mc-brown)] md:text-[15px]">
          {spec.body}
        </p>
        <div className="mt-5 flex items-center justify-center gap-2 md:justify-start">
          <span className="h-1.5 w-1.5 rounded-full bg-[var(--mc-blue)] mc-pulse" />
          <span className="mc-track font-mono-tech text-[9px] text-[var(--mc-cool-grey-ink)]">
            ONLINE · {String(index + 1).padStart(2, "0")} / {String(TILES.length).padStart(2, "0")}
          </span>
        </div>
      </div>
    </motion.div>
  );
}

export function KineticTiles() {
  return (
    <section className="relative z-20 px-6 pb-40 pt-12 md:px-14 md:pb-48">
      <div className="mx-auto flex max-w-3xl flex-col gap-24 md:gap-32">
        {TILES.map((t, i) => (
          <Tile key={t.id} spec={t} index={i} />
        ))}
      </div>
    </section>
  );
}
