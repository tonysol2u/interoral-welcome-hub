import { motion } from "framer-motion";
import badgeTooth from "@/assets/icons/badge-tooth.png";
import dentalHand from "@/assets/icons/dental-care-hand.png";
import dentistPincers from "@/assets/icons/dentist-pincers.png";

const ITEMS = [
  { src: badgeTooth, label: "Clinical Standard", caption: "Certified clinical-grade output" },
  { src: dentalHand, label: "Chairside Care", caption: "From scan to delivery" },
  { src: dentistPincers, label: "Precision Crafted", caption: "Sub-millimeter geometry" },
];

export function IconStrip() {
  return (
    <section className="relative z-20 px-6 pb-16 pt-4 md:px-14 md:pb-20">
      <div className="mx-auto max-w-5xl">
        <div className="grid grid-cols-1 gap-8 sm:grid-cols-3 md:gap-12">
          {ITEMS.map((item, i) => (
            <motion.div
              key={item.label}
              initial={{ opacity: 0, y: 24 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true, amount: 0.4 }}
              transition={{ duration: 0.6, delay: i * 0.08, ease: [0.16, 1, 0.3, 1] }}
              whileHover={{ y: -4 }}
              className="group flex flex-col items-center text-center"
            >
              <div className="relative mb-3 flex h-20 w-20 items-center justify-center rounded-full border border-[var(--mc-brown)]/25 bg-white/40 p-2 md:h-24 md:w-24">
                <div className="absolute inset-0 rounded-full bg-[var(--mc-gold)]/10 blur-xl transition-opacity duration-500 group-hover:opacity-80 opacity-0" />
                <img
                  src={item.src}
                  alt=""
                  className="relative h-full w-full object-contain drop-shadow-[0_6px_14px_rgba(40,30,20,0.45)] transition-transform duration-500 group-hover:scale-110"
                />
              </div>
              <h4 className="font-display text-[15px] font-semibold tracking-tight text-[var(--mc-brown)] md:text-[17px]">
                {item.label}
              </h4>
              <p className="mt-1 max-w-[180px] text-[11px] font-light leading-snug text-[var(--mc-brown)]/70 md:text-[12px]">
                {item.caption}
              </p>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
}
