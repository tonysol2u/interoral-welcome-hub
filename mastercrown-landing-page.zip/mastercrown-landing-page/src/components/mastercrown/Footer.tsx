import { ShieldCheck } from "lucide-react";
import { MasterCoin } from "./MasterCoin";

export function Footer() {
  return (
    <footer
      id="security"
      className="border-t border-[var(--mc-line)] px-6 py-10 md:px-12"
    >
      <div className="flex flex-col gap-6 md:flex-row md:items-center md:justify-between">
        <div className="flex items-center gap-6">
          <span className="mc-track font-mono-tech text-[10px] text-[var(--mc-cool-grey-ink)]">
            HIPAA
          </span>
          <span className="mc-track font-mono-tech text-[10px] text-[var(--mc-cool-grey-ink)]">
            SOC 2 · TYPE II
          </span>
          <span className="mc-track font-mono-tech text-[10px] text-[var(--mc-cool-grey-ink)]">
            ON-PREM OPTION
          </span>
        </div>

        <div className="flex items-center gap-3">
          <span className="h-1.5 w-1.5 rounded-full bg-[var(--mc-blue)]" />
          <span className="font-display text-[15px] font-medium tracking-tight text-[var(--mc-brown)]">
            MasterCrown.ai
          </span>
          <span className="mc-track font-mono-tech text-[10px] text-[var(--mc-cool-grey-ink)]">
            © 2026
          </span>
        </div>
      </div>

      <div className="mt-6 flex items-start gap-2 border-t border-[var(--mc-line)] pt-5 text-[var(--mc-cool-grey-ink)]">
        <ShieldCheck className="mt-0.5 h-3.5 w-3.5 shrink-0 text-[var(--mc-gold)]" />
        <p className="text-[11px] leading-relaxed">
          <span className="font-semibold text-[var(--mc-brown)]">Hashed Transaction Security:</span>{" "}
          All clinical data is de-identified at the source. This ecosystem is powered by{" "}
          <MasterCoin className="text-[11px]" />.
        </p>
      </div>
    </footer>
  );
}
