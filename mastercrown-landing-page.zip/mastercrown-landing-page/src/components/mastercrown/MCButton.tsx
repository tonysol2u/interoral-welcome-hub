import * as React from "react";
import { cn } from "@/lib/utils";

type Variant = "outline" | "solid" | "blue" | "ghost" | "green";

interface MCButtonProps extends React.ButtonHTMLAttributes<HTMLButtonElement> {
  variant?: Variant;
}

const base =
  "mc-tile-sm inline-flex items-center justify-center gap-2 px-5 py-2.5 text-[11px] mc-track uppercase font-medium transition-all duration-300 min-w-[140px]";

const variants: Record<Variant, string> = {
  outline:
    "border border-[var(--mc-brown)] text-[var(--mc-brown)] hover:bg-[var(--mc-brown)] hover:text-white",
  solid:
    "bg-[var(--mc-brown)] text-white border border-[var(--mc-brown)] hover:bg-[var(--mc-brown-soft)]",
  blue: "bg-[var(--mc-blue)] text-white border border-[var(--mc-blue)] hover:bg-[var(--mc-blue-deep)]",
  green:
    "bg-[#3f7a4d] text-white border border-[#3f7a4d] hover:bg-[#34643f]",
  ghost:
    "border border-transparent text-[var(--mc-brown)] hover:border-[var(--mc-line)]",
};

export function MCButton({
  variant = "outline",
  className,
  children,
  ...rest
}: MCButtonProps) {
  return (
    <button className={cn(base, variants[variant], className)} {...rest}>
      {children}
    </button>
  );
}
