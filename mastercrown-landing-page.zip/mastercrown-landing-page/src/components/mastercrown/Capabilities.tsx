import { useRef } from "react";
import useEmblaCarousel from "embla-carousel-react";
import Autoplay from "embla-carousel-autoplay";
import { ChevronLeft, ChevronRight } from "lucide-react";
import { MCTile } from "./MCTile";

const items = [
  {
    idx: "01",
    tag: "PRIVATE",
    title: "Private Inference",
    plain: "The thinking happens inside your practice.",
    body:
      "No patient data ever floats out onto the public internet. Every calculation stays within your perimeter — your network, your rules, your control.",
  },
  {
    idx: "02",
    tag: "FAST",
    title: "Chairside Latency",
    plain: "Built for the patient in the chair, not the queue.",
    body:
      "Designs come back in seconds, not twenty minutes. The cadence matches a working operatory so you keep moving without waiting on a file.",
  },
  {
    idx: "03",
    tag: "DEFENSIBLE",
    title: "Auditable Output",
    plain: "Every design comes with a receipt.",
    body:
      "If anyone ever asks why a tooth was designed a certain way, the system shows the rationale — signed, traced, and exportable. It protects the doctor.",
  },
  {
    idx: "04",
    tag: "VALIDATED",
    title: "Autonomous Design Validation",
    plain: "The crown is checked before it ever reaches you.",
    body:
      "Crown geometry, margin integrity and occlusal contact are continuously validated against the patient's own arch. The design only signs off when every constraint is met, and flags the exact surface when it isn't.",
  },
];

export function Capabilities() {
  const autoplay = useRef(
    Autoplay({ delay: 6500, stopOnInteraction: false, stopOnMouseEnter: true }),
  );
  const [emblaRef, emblaApi] = useEmblaCarousel({ loop: true, align: "center" }, [
    autoplay.current,
  ]);

  return (
    <section id="clinical" className="px-6 pb-24 md:px-12 md:pb-32">
      <div className="mx-auto max-w-3xl">
        <div className="mb-6 flex items-end justify-between">
          <span className="mc-track font-mono-tech text-[10px] text-[var(--mc-gold)]">
            THE FOUR PILLARS
          </span>
          <span className="mc-track hidden font-mono-tech text-[10px] text-[var(--mc-cool-grey-ink)] md:inline">
            WHAT MAKES IT SAFE
          </span>
        </div>
        <h2 className="mb-10 max-w-2xl font-display text-[28px] font-light leading-[1.1] tracking-[-0.01em] text-[var(--mc-brown)] md:text-[36px]">
          Four things that make a doctor feel safe.
        </h2>

        <div className="relative">
          <div className="overflow-hidden" ref={emblaRef}>
            <div className="flex">
              {items.map((it) => (
                <div
                  key={it.idx}
                  className="min-w-0 flex-[0_0_100%] px-2 md:flex-[0_0_70%] md:px-3"
                >
                  <MCTile variant="white" size="sm" className="p-7 h-full">
                    <div className="flex items-start justify-between">
                      <span className="mc-track font-mono-tech text-[10px] text-[var(--mc-gold)]">
                        {it.idx} · {it.tag}
                      </span>
                      <span className="h-1.5 w-1.5 rounded-full bg-[var(--mc-gold)]" />
                    </div>
                    <h3 className="mt-10 font-display text-[24px] font-medium leading-tight tracking-tight text-[var(--mc-brown)]">
                      {it.title}
                    </h3>
                    <p className="mt-3 text-[14px] font-light italic leading-snug text-[var(--mc-brown)]">
                      {it.plain}
                    </p>
                    <p className="mt-3 text-[13px] font-light leading-relaxed text-[var(--mc-brown-soft)]">
                      {it.body}
                    </p>
                  </MCTile>
                </div>
              ))}
            </div>
          </div>

          <button
            type="button"
            onClick={() => emblaApi?.scrollPrev()}
            aria-label="Previous"
            className="absolute -left-2 top-1/2 -translate-y-1/2 inline-flex h-10 w-10 items-center justify-center rounded-full border border-[var(--mc-gold)]/40 bg-white/85 text-[var(--mc-brown)] backdrop-blur-md shadow-[0_10px_30px_-10px_rgba(40,30,20,0.4)] transition-colors hover:bg-white md:-left-6"
          >
            <ChevronLeft className="h-5 w-5" />
          </button>
          <button
            type="button"
            onClick={() => emblaApi?.scrollNext()}
            aria-label="Next"
            className="absolute -right-2 top-1/2 -translate-y-1/2 inline-flex h-10 w-10 items-center justify-center rounded-full border border-[var(--mc-gold)]/40 bg-white/85 text-[var(--mc-brown)] backdrop-blur-md shadow-[0_10px_30px_-10px_rgba(40,30,20,0.4)] transition-colors hover:bg-white md:-right-6"
          >
            <ChevronRight className="h-5 w-5" />
          </button>
        </div>
      </div>
    </section>
  );
}
