import mcLogo from "@/assets/icons/mastercrown-logo.png";
import caduceus from "@/assets/icons/caduceus.png";

export function Hero() {
  return (
    <div className="relative flex flex-col px-6 py-6 md:px-10 md:py-8">
      {/* Cascading: round logo → wordmark → subparagraph → body */}
      <div className="flex flex-col items-center gap-6 text-center">
        <div
          aria-label="MasterCrown.ai"
          role="img"
          className="h-44 w-44 md:h-56 md:w-56 aspect-square rounded-full drop-shadow-[0_14px_28px_rgba(0,0,0,0.55)]"
          style={{
            backgroundImage: `url(${mcLogo})`,
            backgroundSize: "cover",
            backgroundPosition: "center center",
            backgroundRepeat: "no-repeat",
          }}
        />
        <div className="flex items-center justify-center gap-5 md:gap-7">
          <img
            src={caduceus}
            alt=""
            aria-hidden
            className="h-20 w-20 md:h-28 md:w-28 object-contain drop-shadow-[0_6px_14px_rgba(40,30,20,0.35)]"
          />
          <h1
            className="font-display font-light tracking-[-0.04em] text-[var(--mc-brown)] whitespace-nowrap"
            style={{
              fontSize: "clamp(28px, 5.5vw, 72px)",
              lineHeight: 1,
              textShadow:
                "0 1px 0 rgba(255,255,255,0.5), 0 8px 20px rgba(40,30,20,0.2)",
            }}
          >
            MasterCrown<span className="text-[var(--mc-brown)]">.ai</span>
          </h1>
        </div>

        <p className="text-[14px] font-extralight leading-relaxed text-[var(--mc-cool-grey-ink)] md:text-[15px] max-w-md">
          Clinical Intelligence for the Modern Dental Office.
        </p>

        <div className="max-w-2xl space-y-4">
          <p className="text-[13px] font-light leading-[1.6] text-[var(--mc-brown)] md:text-[14px]">
            MasterCrown is a{" "}
            <span className="font-medium">clinical reasoning system</span> that
            understands the specific rules of dental anatomy. Powered by our{" "}
            <span className="font-medium">Book Smart agent</span>, the engine
            automatically applies correct{" "}
            <span className="italic">Golden Proportions</span>,{" "}
            <span className="italic">Buccal Corridor harmony</span>, and precise
            incisal edge positioning to every case. Instead of generic shapes,
            it calculates the ideal length and inclination for your bridges and
            interiors, ensuring an arrangement that is both clinically sound and
            aesthetically balanced.
          </p>
        </div>
      </div>
    </div>
  );
}
