import * as React from "react";
import { cn } from "@/lib/utils";

type Variant = "glass" | "white" | "outline" | "ink";
type Size = "sm" | "md" | "lg";

interface MCTileProps extends React.HTMLAttributes<HTMLDivElement> {
  variant?: Variant;
  size?: Size;
  asChild?: boolean;
}

const variantClass: Record<Variant, string> = {
  glass: "mc-glass",
  white: "bg-white border border-[var(--mc-line)]",
  outline: "bg-transparent border border-[var(--mc-line)]",
  ink: "bg-[var(--mc-brown)] text-white border border-[var(--mc-brown)]",
};

const sizeClass: Record<Size, string> = {
  sm: "mc-tile-sm",
  md: "mc-tile",
  lg: "mc-tile-lg",
};

export function MCTile({
  variant = "white",
  size = "md",
  className,
  children,
  ...rest
}: MCTileProps) {
  return (
    <div
      className={cn(
        "relative overflow-hidden",
        sizeClass[size],
        variantClass[variant],
        className,
      )}
      {...rest}
    >
      {children}
    </div>
  );
}
