import { MCButton } from "./MCButton";

export function Nav() {
  return (
    <header className="relative z-20 flex items-center justify-between px-6 py-5 md:px-12 md:py-7">
      <div className="flex items-center gap-3">
        <div className="mc-tile-sm flex h-9 w-9 items-center justify-center bg-[var(--mc-brown)] text-white">
          <span className="font-display text-[15px] font-black leading-none">M</span>
        </div>
        <div className="flex flex-col leading-none">
          <span className="mc-track text-[10px] text-[var(--mc-cool-grey-ink)]">
            MASTERCROWN
          </span>
          <span className="font-display text-[13px] font-medium tracking-tight text-[var(--mc-brown)]">
            .ai / clinical
          </span>
        </div>
      </div>

      <nav className="mc-track hidden items-center gap-9 text-[11px] text-[var(--mc-cool-grey-ink)] md:flex">
        <a href="#platform" className="hover:text-[var(--mc-brown)]">Platform</a>
        <a href="#clinical" className="hover:text-[var(--mc-brown)]">Clinical</a>
        <a href="#security" className="hover:text-[var(--mc-brown)]">Security</a>
      </nav>

      <div className="flex items-center gap-3">
        <span className="mc-track hidden text-[10px] text-[var(--mc-cool-grey-ink)] lg:inline">
          STATUS&nbsp;·&nbsp;
          <span className="text-[var(--mc-blue)]">SYSTEM NOMINAL</span>
        </span>
        <MCButton variant="outline">Partner Login</MCButton>
      </div>
    </header>
  );
}
