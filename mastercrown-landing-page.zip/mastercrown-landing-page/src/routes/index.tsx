import { createFileRoute } from "@tanstack/react-router";
import { Hero } from "@/components/mastercrown/Hero";
import { Capabilities } from "@/components/mastercrown/Capabilities";
import { Footer } from "@/components/mastercrown/Footer";
import { KineticTiles } from "@/components/mastercrown/KineticTiles";
import { IconStrip } from "@/components/mastercrown/IconStrip";
import { ValuePillars } from "@/components/mastercrown/ValuePillars";
import { BottomNav } from "@/components/mastercrown/BottomNav";
import cubesPattern from "@/assets/textures/cubes-pattern.jpg";
import brokenChain from "@/assets/textures/broken-chain.jpg";
import triangleMesh from "@/assets/textures/triangle-mesh.png";

export const Route = createFileRoute("/")({
  component: Index,
});

function Index() {
  return (
    <main
      className="relative min-h-screen"
      style={{
        background:
          "radial-gradient(ellipse 40% 32% at 50% 28%, oklch(0.9 0.02 248) 0%, oklch(0.82 0.03 250) 55%, transparent 100%), radial-gradient(ellipse at 50% 50%, oklch(0.7 0.04 250) 0%, oklch(0.55 0.05 252) 70%, oklch(0.45 0.05 253) 100%)",
      }}
    >
      {/* Particle / texture mesh — OUTSIDE the tile, on the smoky blue */}
      <div
        aria-hidden
        className="pointer-events-none fixed inset-0 z-0"
        style={{
          backgroundImage: `url(${brokenChain})`,
          backgroundSize: "cover",
          backgroundPosition: "center",
          backgroundRepeat: "no-repeat",
          opacity: 0.18,
          mixBlendMode: "screen",
        }}
      />
      <div
        aria-hidden
        className="pointer-events-none fixed inset-0 z-0"
        style={{
          backgroundImage: `url(${cubesPattern})`,
          backgroundSize: "auto",
          backgroundRepeat: "repeat",
          opacity: 0.25,
          mixBlendMode: "overlay",
        }}
      />
      <div
        aria-hidden
        className="pointer-events-none fixed inset-0 z-0"
        style={{
          backgroundImage: `url(${triangleMesh})`,
          backgroundSize: "cover",
          backgroundPosition: "center",
          backgroundRepeat: "no-repeat",
          opacity: 0.3,
          mixBlendMode: "overlay",
        }}
      />
      {/* Vignette */}
      <div
        aria-hidden
        className="pointer-events-none fixed inset-0 z-0"
        style={{
          background:
            "radial-gradient(ellipse at center, transparent 40%, rgba(0,0,0,0.45) 100%)",
        }}
      />

      <div className="relative z-10 flex flex-col items-center">
        {/* MasterCrown logo + subtext (no border frame) */}
        <div className="mt-16 w-full max-w-3xl px-6">
          <Hero />
        </div>

        {/* Hero video — oval, no black border */}
        <div
          className="group relative mt-4 mb-24 aspect-[21/9] w-[560px] md:w-[760px] overflow-hidden cursor-pointer shadow-[0_30px_60px_-30px_rgba(40,30,20,0.55)]"
          style={{ borderRadius: "9999px" }}
          onClick={(e) => {
            const wrap = e.currentTarget;
            const v = wrap.querySelector("video") as HTMLVideoElement | null;
            if (!v) return;
            v.muted = !v.muted;
            v.play().catch(() => {});
            wrap.dataset.muted = String(v.muted);
          }}
          data-muted="true"
        >
          <video className="h-full w-full object-contain bg-white" autoPlay muted loop playsInline>
            <source src="/mastercrown-bridge.mp4" type="video/mp4" />
          </video>
          <div className="pointer-events-none absolute bottom-6 left-1/2 -translate-x-1/2 rounded-full bg-black/60 px-3 py-1 text-[10px] font-mono uppercase tracking-widest text-white transition-opacity group-data-[muted=false]:opacity-0">
            Tap for sound
          </div>
        </div>

        <div className="w-full">
          <IconStrip />
          <KineticTiles />
          <Capabilities />
          <ValuePillars />
          <Footer />
        </div>
      </div>

      <BottomNav />
    </main>
  );
}
