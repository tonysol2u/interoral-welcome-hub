import { useEffect, useState } from "react";
import { supabase } from "@/integrations/supabase/client";

const LOGO = "/mastercoin-logo.png";

const SAMPLE_BALANCE = "1,250.00";
const SAMPLE_NAME = "VALUED MEMBER";
const SAMPLE_ACCOUNT = "MSTL-000000";

function formatBalance(n: number | null | undefined) {
  if (n === null || n === undefined) return SAMPLE_BALANCE;
  return n.toLocaleString("en-US", { minimumFractionDigits: 2, maximumFractionDigits: 2 });
}

function deriveFirstName(fullName: string | null | undefined, email: string | null | undefined) {
  if (fullName && fullName.trim()) return fullName.trim().split(/\s+/)[0].toUpperCase();
  if (email) return email.split("@")[0].toUpperCase();
  return SAMPLE_NAME;
}

function shortAccountId(uuid: string) {
  return `MSTL-${uuid.replace(/-/g, "").slice(0, 6).toUpperCase()}`;
}

export function MasterCoinStaticLedger() {
  const [holder, setHolder] = useState(`DR. ${SAMPLE_NAME}`);
  const [balance, setBalance] = useState(SAMPLE_BALANCE);
  const [accountId, setAccountId] = useState(SAMPLE_ACCOUNT);

  useEffect(() => {
    let active = true;
    (async () => {
      const { data: { session } } = await supabase.auth.getSession();
      const user = session?.user;
      if (!user || !active) return;

      const [{ data: profile }, { data: tokens }] = await Promise.all([
        supabase.from("profiles").select("full_name, email").eq("id", user.id).maybeSingle(),
        supabase.from("user_tokens").select("balance").eq("user_id", user.id).maybeSingle(),
      ]);
      if (!active) return;

      setHolder(`DR. ${deriveFirstName(profile?.full_name, profile?.email ?? user.email)}`);
      setAccountId(shortAccountId(user.id));
      if (tokens?.balance !== undefined && tokens?.balance !== null) {
        setBalance(formatBalance(tokens.balance));
      }
    })();
    return () => { active = false; };
  }, []);

  return (
    <main className="mc-static-ledger">
      <style>{`
        @import url('https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800&family=JetBrains+Mono:wght@500;600;700&display=swap');
        .mc-static-ledger, .mc-static-ledger * { box-sizing: border-box; }
        .mc-static-ledger {
          --mc-bg: #ffffff;
          --mc-soft: #f6f8fb;
          --mc-panel: #ffffff;
          --mc-navy: #0a1f4a;
          --mc-blue: #1d5bd6;
          --mc-ink: #0c1a36;
          --mc-muted: #6b7280;
          --mc-line: #e3e8ef;
          --mc-gold: #c9a84c;
          width: 100%;
          min-height: 100svh;
          overflow-x: hidden;
          background: var(--mc-bg);
          color: var(--mc-ink);
          font-family: 'Inter', ui-sans-serif, system-ui, sans-serif;
        }
        .mc-shell { max-width: 1080px; margin: 0 auto; padding: 22px clamp(16px, 3vw, 28px) 28px; }
        .mc-top { display:flex; align-items:center; justify-content:space-between; gap:18px; border-bottom:1px solid var(--mc-line); padding-bottom:16px; margin-bottom:24px; }
        .mc-brand { display:flex; align-items:center; gap:12px; min-width:0; }
        .mc-logo { width:42px; height:42px; object-fit:contain; flex:0 0 auto; }
        .mc-brand-title { font-size:17px; font-weight:700; color:var(--mc-navy); line-height:1; letter-spacing:-0.01em; }
        .mc-brand-title .dot { color:var(--mc-blue); }
        .mc-brand-sub { margin-top:5px; font-size:9.5px; letter-spacing:.18em; text-transform:uppercase; font-weight:600; color:var(--mc-muted); }
        .mc-status { display:inline-flex; align-items:center; gap:8px; white-space:nowrap; font-size:10.5px; letter-spacing:.14em; text-transform:uppercase; color:var(--mc-muted); font-weight:700; }
        .mc-dot { width:8px; height:8px; border-radius:999px; background:var(--mc-blue); box-shadow:0 0 0 4px rgba(29,91,214,.12); }
        .mc-eyebrow { color:var(--mc-blue); font-size:11px; letter-spacing:.22em; text-transform:uppercase; font-weight:700; margin-bottom:10px; }
        .mc-title { color:var(--mc-navy); font-size:clamp(26px, 3vw, 34px); line-height:1.05; margin:0 0 12px; font-weight:700; letter-spacing:-0.02em; max-width:780px; }
        .mc-lede { max-width:680px; color:var(--mc-muted); font-size:14px; line-height:1.6; margin:0 0 26px; }
        .mc-grid { display:grid; grid-template-columns:minmax(0, 1fr) 320px; gap:20px; align-items:start; }
        .mc-panel { background:var(--mc-panel); border:1px solid var(--mc-line); border-radius:10px; padding:22px; }
        .mc-card-stage { padding:24px; background:var(--mc-soft); }
        .mc-asset-card {
          position:relative;
          overflow:hidden;
          width:100%;
          max-width:520px;
          border-radius:14px;
          padding:22px 24px;
          color:#fff;
          background:linear-gradient(135deg, #061735 0%, #0a2362 55%, #0e367f 100%);
          box-shadow:0 22px 48px -24px rgba(8,28,72,.45);
          display:flex;
          flex-direction:column;
          gap:14px;
        }
        .mc-card-top { display:flex; align-items:flex-start; justify-content:space-between; gap:14px; }
        .mc-card-kicker { font-size:9.5px; letter-spacing:.2em; text-transform:uppercase; color:rgba(255,255,255,.6); font-weight:700; }
        .mc-card-name { margin-top:4px; font-size:15px; font-weight:700; color:#fff; letter-spacing:-0.01em; }
        .mc-card-logo { width:96px; height:96px; object-fit:contain; flex:0 0 auto; filter: drop-shadow(0 4px 12px rgba(201,168,76,0.35)); }
        .mc-balance { display:flex; align-items:baseline; gap:8px; min-width:0; }
        .mc-balance-value { font-family:'JetBrains Mono', ui-monospace, monospace; font-size:clamp(26px, 4vw, 34px); font-weight:600; letter-spacing:-0.01em; overflow-wrap:anywhere; }
        .mc-balance-unit { color:rgba(255,255,255,.6); letter-spacing:.16em; font-size:11px; font-weight:700; }
        .mc-number { font-family:'JetBrains Mono', ui-monospace, monospace; font-size:13px; letter-spacing:.18em; color:rgba(255,255,255,.78); }
        .mc-card-foot { display:grid; grid-template-columns:minmax(0, 1.4fr) auto auto; align-items:end; gap:14px; }
        .mc-label { color:rgba(255,255,255,.5); text-transform:uppercase; letter-spacing:.18em; font-size:8px; font-weight:700; }
        .mc-value, .mc-holder { margin-top:3px; font-family:'JetBrains Mono', ui-monospace, monospace; color:#fff; font-size:11px; font-weight:600; letter-spacing:.06em; }
        .mc-holder { font-size:12px; letter-spacing:.08em; overflow:hidden; text-overflow:ellipsis; white-space:nowrap; }
        .mc-card-tag { padding-top:10px; border-top:1px solid rgba(255,255,255,.12); font-size:9.5px; letter-spacing:.18em; text-transform:uppercase; color:rgba(255,255,255,.62); font-weight:600; display:flex; justify-content:space-between; gap:10px; }
        .mc-section-label { margin:24px 0 10px; color:var(--mc-muted); font-size:10.5px; letter-spacing:.16em; text-transform:uppercase; font-weight:700; }
        .mc-side-title { font-size:15px; color:var(--mc-navy); font-weight:700; margin:0 0 10px; letter-spacing:-0.01em; }
        .mc-row { display:flex; justify-content:space-between; gap:14px; padding:11px 0; border-bottom:1px solid var(--mc-line); font-size:12.5px; }
        .mc-row:last-child { border-bottom:0; }
        .mc-row span:first-child { color:var(--mc-muted); }
        .mc-row strong { color:var(--mc-ink); font-family:'JetBrains Mono', ui-monospace, monospace; font-weight:600; text-align:right; overflow-wrap:anywhere; }
        .mc-rate-note { margin-top:12px; font-size:11px; color:var(--mc-muted); line-height:1.55; }
        .currency-exchange-card { width:100%; max-width:1280px; margin:0 auto 1.25rem; padding:1.5rem; border-radius:1rem; border:1px solid #e2e8f0; background:#fff; display:grid; grid-template-columns:1fr 1fr; gap:1.5rem; align-items:center; min-height:120px; }
        .cex-col { display:flex; flex-direction:column; gap:6px; min-width:0; }
        .cex-right { padding-left:1.5rem; border-left:1px solid var(--mc-line); }
        .cex-label { font-size:10px; letter-spacing:.18em; text-transform:uppercase; color:var(--mc-muted); font-weight:700; }
        .cex-balance { display:flex; align-items:baseline; gap:8px; }
        .cex-amount { font-family:'JetBrains Mono', ui-monospace, monospace; font-size:28px; font-weight:600; color:var(--mc-navy); letter-spacing:-0.01em; overflow-wrap:anywhere; }
        .cex-unit { font-size:12px; font-weight:700; color:var(--mc-muted); letter-spacing:.14em; }
        .cex-rate { font-family:'JetBrains Mono', ui-monospace, monospace; font-size:22px; font-weight:600; color:var(--mc-navy); letter-spacing:-0.01em; display:flex; align-items:center; gap:8px; flex-wrap:wrap; }
        .cex-flag { font-size:22px; line-height:1; }
        .cex-meta { font-size:11.5px; color:var(--mc-muted); display:flex; align-items:center; gap:6px; flex-wrap:wrap; }
        .cex-meta strong { color:var(--mc-ink); font-weight:600; }
        @media (max-width: 720px) { .currency-exchange-card { grid-template-columns:1fr; gap:1rem; } .cex-right { padding-left:0; padding-top:1rem; border-left:0; border-top:1px solid var(--mc-line); } }
        .mc-section-title { font-size:clamp(20px, 2.4vw, 26px); color:var(--mc-navy); font-weight:700; margin:38px 0 6px; letter-spacing:-0.02em; }
        .mc-tiles { display:grid; grid-template-columns:repeat(2, 1fr); gap:12px; margin-top:14px; }
        .mc-tile { background:#fff; border:1px solid var(--mc-line); border-radius:8px; padding:18px; }
        .mc-tile-num { font-family:'JetBrains Mono', ui-monospace, monospace; color:var(--mc-blue); font-size:10.5px; letter-spacing:.14em; text-transform:uppercase; font-weight:700; }
        .mc-tile-title { color:var(--mc-navy); font-size:16px; font-weight:700; margin:7px 0 6px; letter-spacing:-0.01em; }
        .mc-tile-body { color:var(--mc-muted); font-size:12.5px; line-height:1.55; }
        .mc-footer { margin-top:34px; border-top:1px solid var(--mc-line); padding-top:18px; color:var(--mc-muted); font-size:10.5px; line-height:1.6; }
        .mc-badges { display:flex; flex-wrap:wrap; gap:8px; margin-bottom:10px; }
        .mc-badges span { border:1px solid var(--mc-line); border-radius:999px; padding:5px 10px; color:var(--mc-navy); text-transform:uppercase; font-size:9.5px; letter-spacing:.12em; font-weight:700; }
        @media (max-width: 980px) { .mc-grid { grid-template-columns:1fr; } }
        @media (max-width: 720px) { .mc-top { align-items:flex-start; flex-direction:column; } .mc-tiles { grid-template-columns:1fr; } .mc-card-stage { padding:16px; } .mc-asset-card { padding:18px; } .mc-card-foot { grid-template-columns:1fr 1fr; } .mc-card-logo { width:72px; height:72px; } }
      `}</style>

      <div className="mc-shell">
        <header className="mc-top">
          <div className="mc-brand">
            <img className="mc-logo" src={LOGO} alt="MasterSTL.ai" />
            <div>
              <div className="mc-brand-title">MasterSTL<span className="dot">.ai</span></div>
              <div className="mc-brand-sub">MasterCredit · Direct Settlement Ledger</div>
            </div>
          </div>
          <div className="mc-status"><span className="mc-dot" /> Session Secure</div>
        </header>

        <div className="mc-eyebrow">MasterSTL.ai · Universal Payment Exchange</div>
        <h1 className="mc-title">MasterCredit Digital Ledger</h1>
        <p className="mc-lede">MasterSTL.ai is a direct settlement ledger for the global dental economy. Your MasterCredit balance updates in real time from your account.</p>

        <section className="mc-grid" aria-label="MasterCredit Digital Ledger">
          <div className="mc-panel mc-card-stage">
            <div className="mc-asset-card" aria-label="Digital Asset Card">
              <div className="mc-card-top">
                <div>
                  <div className="mc-card-kicker">MasterCredit Reserve</div>
                  <div className="mc-card-name">Digital Asset Card</div>
                </div>
                <img className="mc-card-logo" src={LOGO} alt="MasterSTL" />
              </div>

              <div className="mc-balance">
                <span className="mc-balance-value">{balance}</span>
                <span className="mc-balance-unit">MC</span>
              </div>

              <div className="mc-number">8800 4210 •••• 2024</div>

              <div className="mc-card-foot">
                <div>
                  <div className="mc-label">Cardholder</div>
                  <div className="mc-holder">{holder}</div>
                </div>
                <div>
                  <div className="mc-label">Member Since</div>
                  <div className="mc-value">2024</div>
                </div>
                <div>
                  <div className="mc-label">Valid Thru</div>
                  <div className="mc-value">12/28</div>
                </div>
              </div>

              <div className="mc-card-tag">
                <span>MasterSTL.ai</span>
                <span>Settlement Network</span>
              </div>
            </div>

            <div className="mc-section-label">Currency Exchange</div>
            <div className="currency-exchange-card" aria-label="Currency exchange">
              <div className="cex-col">
                <div className="cex-label">Your Balance</div>
                <div className="cex-balance">
                  <span className="cex-amount">{balance}</span>
                  <span className="cex-unit">MC</span>
                </div>
                <div className="cex-meta"><span className="cex-flag" aria-hidden>🇺🇸</span> Detected currency: <strong>USD</strong></div>
              </div>
              <div className="cex-col cex-right">
                <div className="cex-label">Conversion Preview</div>
                <div className="cex-rate"><span className="cex-flag" aria-hidden>🇺🇸</span> 1 MC = $1.00 USD</div>
                <div className="cex-meta">Rate updates daily via MasterSTL pricing API</div>
              </div>
            </div>
          </div>

          <aside className="mc-panel mc-side" aria-label="Account summary">
            <h2 className="mc-side-title">Account</h2>
            <div className="mc-row"><span>Account ID</span><strong>{accountId}</strong></div>
            <div className="mc-row"><span>Balance</span><strong>{balance} MC</strong></div>
            <div className="mc-row"><span>Daily Rate</span><strong>—</strong></div>
            <div className="mc-row"><span>Status</span><strong>Active</strong></div>
            <p className="mc-rate-note">Rates refresh daily from the MasterSTL pricing API.</p>
          </aside>
        </section>

        <h2 className="mc-section-title">Where MasterCredit Spends</h2>
        <p className="mc-lede">Every MasterCredit redeems for usable value across design, export, and manufacturing through verified partners.</p>
        <section className="mc-tiles" aria-label="MasterCredit usage">
          <article className="mc-tile">
            <div className="mc-tile-num">01 · AI Designs</div>
            <div className="mc-tile-title">AI Design Renders</div>
            <div className="mc-tile-body">Redeem MasterCredit for clinical-grade crown, bridge, implant, and smile design renders.</div>
          </article>
          <article className="mc-tile">
            <div className="mc-tile-num">02 · STL Exports</div>
            <div className="mc-tile-title">Manufacturing Files</div>
            <div className="mc-tile-body">Use balances for STL, PLY, and manufacturing-ready file exports for mills and printers.</div>
          </article>
        </section>

        <footer className="mc-footer">
          <div className="mc-badges"><span>HIPAA Ready</span><span>GDPR Ready</span><span>MasterSTL.ai</span></div>
          <p>MasterSTL.ai · MasterCredit is an internal settlement utility for the global dental economy. Not a security. All transactions processed via the MasterSTL Settlement Network.</p>
        </footer>
      </div>
    </main>
  );
}
