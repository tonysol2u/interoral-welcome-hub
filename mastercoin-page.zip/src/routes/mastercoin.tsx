import { createFileRoute } from "@tanstack/react-router";
import { MasterCoinStaticLedger } from "@/components/MasterCoinStaticLedger";

export const Route = createFileRoute("/mastercoin")({
  head: () => ({
    meta: [
      { title: "MasterCoin Digital Ledger" },
      { name: "description", content: "Direct MasterCoin Digital Ledger account view for the global dental economy." },
      { name: "robots", content: "noindex, nofollow" },
    ],
  }),
  component: MasterCoinStaticLedger,
});
