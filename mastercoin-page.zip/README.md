# MasterCoin / MasterSTL.ai – MasterCredit Digital Ledger

Single-page React component for the MasterCredit ledger view.

## Files
- `src/components/MasterCoinStaticLedger.tsx` — the page component (self-contained styles).
- `src/routes/mastercoin.tsx` — TanStack Start route wrapper at `/mastercoin`.
- `src/integrations/supabase/client.ts` — Supabase browser client (auto-generated; do not edit).
- `public/mastercoin-logo.png` — coin/brand logo used on the card and header.

## Dynamic data
On mount, the component reads the signed-in user's session and queries:
- `profiles` → `full_name`, `email` (for cardholder name)
- `user_tokens` → `balance` (for MasterCredit balance)

Falls back to a sample balance (1,250.00 MC) and "VALUED MEMBER" when no user is signed in.

## Env vars required
- `VITE_SUPABASE_URL`
- `VITE_SUPABASE_PUBLISHABLE_KEY`
