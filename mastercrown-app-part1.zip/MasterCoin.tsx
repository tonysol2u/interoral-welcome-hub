import { cn } from "@/lib/utils";

/** Gold MasterCoin wordmark — use anywhere the currency is named. */
export function MasterCoin({
  className,
  plural = false,
  as: Tag = "span",
}: {
  className?: string;
  plural?: boolean;
  as?: "span" | "strong";
}) {
  return (
    <Tag className={cn("mastercoin-text", className)}>
      MasterCredit{plural ? "s" : ""}
    </Tag>
  );
}
