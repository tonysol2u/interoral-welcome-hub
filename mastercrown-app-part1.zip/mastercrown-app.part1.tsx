import { createFileRoute, Link } from "@tanstack/react-router";
import { useState, useCallback, useEffect } from "react";
import { motion, AnimatePresence } from "framer-motion";
import {
  Sparkles, Upload, Send, Ruler, Zap, Clock, Shield,
  Crown, Layers, Box, Lock, CheckCircle2, XCircle, Loader2,
  Flame, ExternalLink, ChevronDown
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { toast } from "sonner";
import { cn } from "@/lib/utils";
import cubesPattern from "@/assets/textures/cubes-pattern.jpg";
import brokenChain from "@/assets/textures/broken-chain.jpg";
import triangleMesh from "@/assets/textures/triangle-mesh.png";
import toothCoin from "@/assets/icons/badge-tooth.png";
import mcLogo from "@/assets/icons/mastercrown-logo.png";
import { TokenBalance } from "@/components/mastercrown/TokenBalance";
import { TopUpModal } from "@/components/mastercrown/TopUpModal";
import { MasterCoin } from "@/components/mastercrown/MasterCoin";

export const Route = createFileRoute("/mastercrown-app")({
  head: () => ({
    meta: [
      { title: "MasterCrown.ai — Express AI Design" },
      { name: "description", content: "Upload your scan and receive precision-engineered STL designs in minutes." },
      { name: "robots", content: "noindex, nofollow" },
    ],
  }),
  component: MasterCrownApp,
});

/* ────── PRICING ────── */
const PRICE_CROWN = 15;
const PRICE_BRIDGE = 20;
const PRICE_MODEL_PER_ARCH = 3;
const ABANDON_FEE = 5;

const DEFAULTS = [
  { label: "Contacts Distance", value: "-0.03 mm" },
  { label: "Occlusion Distance", value: "0.30 mm" },
  { label: "Undercuts", value: "Remove" },
  { label: "Emergence Profile", value: "Regular" },
];

type CaseCategory = "crowns" | "bridges" | "copings";

const CATEGORIES: { id: CaseCategory; label: string; icon: typeof Crown; enabled: boolean; price: string }[] = [
  { id: "crowns", label: "Crowns", icon: Crown, enabled: true, price: `$${PRICE_CROWN}/unit` },
  { id: "bridges", label: "Bridges (3-Unit)", icon: Layers, enabled: true, price: `$${PRICE_BRIDGE}/unit` },
  { id: "copings", label: "Copings", icon: Shield, enabled: true, price: `$${PRICE_CROWN}/unit` },
];

/* ────── DESIGN PREFERENCES (per service) ────── */
type PrefField = { key: string; label: string; options: string[] };
const PREFS: Record<CaseCategory, { title: string; sectionLabel: string; fields: PrefField[] }> = {
  crowns: {
    title: "Crown — Design Preferences",
    sectionLabel: "Crown — Design Preferences",
    fields: [
      { key: "style", label: "Style", options: ["Natural", "Youthful", "Mature"] },
      { key: "contactsShape", label: "Contacts Shape", options: ["Regular", "Very Broad"] },
      { key: "occlusal", label: "Occlusal", options: ["Light", "Medium", "Heavy"] },
      { key: "incisalCharacter", label: "Incisal Character", options: ["Youthful", "Natural", "Mature"] },
    ],
  },
  bridges: {
    title: "Bridge — Design Preferences",
    sectionLabel: "3-Unit Bridge — Design Preferences",
    fields: [
      { key: "contactsDistance", label: "Contacts Distance", options: ["Tight", "Medium", "Open"] },
      { key: "style", label: "Style", options: ["Regular", "Mature", "Youthful"] },
      { key: "gingivalDistance", label: "Gingival Distance", options: ["0.00 mm", "0.25 mm", "0.50 mm"] },
      { key: "ponticShape", label: "Pontic Shape", options: ["Saddle", "Modified Ridge Lap", "Ovate", "Bullet"] },
    ],
  },
  copings: {
    title: "Coping — Design Preferences",
    sectionLabel: "Coping — Design Preferences",
    fields: [
      { key: "thickness", label: "Wall Thickness", options: ["0.30 mm", "0.40 mm", "0.50 mm"] },
      { key: "marginType", label: "Margin Type", options: ["Chamfer", "Shoulder", "Knife-Edge"] },
      { key: "cementGap", label: "Cement Gap", options: ["0.03 mm", "0.05 mm", "0.08 mm"] },
      { key: "collar", label: "Lingual Collar", options: ["None", "Minimal", "Full"] },
    ],
  },
};

type StyleOption = "Regular" | "Mature" | "Youthful";
type ContactShape = "Regular" | "Very Broad";
type WorkflowState = "configure" | "processing" | "review";

const upperTeeth = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16];
const lowerTeeth = [32, 31, 30, 29, 28, 27, 26, 25, 24, 23, 22, 21, 20, 19, 18, 17];

function MasterToothChart({ selectedTeeth, onToothClick }: { selectedTeeth: number[]; onToothClick: (n: number) => void }) {
  const ToothBtn = ({ tooth, isUpper }: { tooth: number; isUpper: boolean }) => {
    const selected = selectedTeeth.includes(tooth);
    return (
      <button
        type="button"
        onClick={() => onToothClick(tooth)}
        className={cn(
          "relative rounded-lg border-2 transition-all duration-200 flex flex-col items-center justify-center w-8 h-10 text-[11px] font-bold",
          "hover:scale-110 focus:outline-none",
          selected
            ? "border-[var(--mc-brown)] bg-[var(--mc-brown)]/15 text-[var(--mc-brown)] shadow-md"
            : "border-[var(--mc-brown)]/20 bg-white/60 text-[var(--mc-brown)]/70 hover:border-[var(--mc-brown)]/50 hover:bg-white"
        )}
      >
        <div className={cn(
          "w-4 h-5 rounded-sm transition-colors",
          selected ? "bg-[var(--mc-brown)]" : "bg-[var(--mc-brown)]/25",
          isUpper ? "rounded-t-md" : "rounded-b-md"
        )} />
        <span className="leading-none mt-0.5">{tooth}</span>
      </button>
    );
  };

  return (
    <div className="flex flex-col items-center gap-2 py-3">
      <span className="text-[10px] text-[var(--mc-brown)]/60 uppercase tracking-widest font-medium">Upper Arch</span>
      <div className="flex items-end justify-center gap-0.5">
        <div className="flex gap-0.5">{upperTeeth.slice(0, 8).map(t => <ToothBtn key={t} tooth={t} isUpper />)}</div>
        <div className="w-px h-10 bg-[var(--mc-gold)]/50 mx-1" />
        <div className="flex gap-0.5">{upperTeeth.slice(8).map(t => <ToothBtn key={t} tooth={t} isUpper />)}</div>
      </div>
      <div className="flex items-center gap-2 my-0.5">
        <div className="h-px w-8 bg-gradient-to-r from-transparent to-[var(--mc-gold)]/60" />
        <Sparkles className="w-2.5 h-2.5 text-[var(--mc-gold)]" />
        <div className="h-px w-8 bg-gradient-to-l from-transparent to-[var(--mc-gold)]/60" />
      </div>
      <div className="flex items-start justify-center gap-0.5">
        <div className="flex gap-0.5">{lowerTeeth.slice(0, 8).map(t => <ToothBtn key={t} tooth={t} isUpper={false} />)}</div>
        <div className="w-px h-10 bg-[var(--mc-gold)]/50 mx-1" />
        <div className="flex gap-0.5">{lowerTeeth.slice(8).map(t => <ToothBtn key={t} tooth={t} isUpper={false} />)}</div>
      </div>
      <span className="text-[10px] text-[var(--mc-brown)]/60 uppercase tracking-widest font-medium">Lower Arch</span>
    </div>
  );
}

function PillSelect<T extends string>({ label, options, value, onChange }: { label: string; options: T[]; value: T; onChange: (v: T) => void }) {
  return (
    <div className="space-y-2">
      <Label className="text-[var(--mc-brown)] text-sm font-semibold">{label}</Label>
      <div className="flex flex-wrap gap-2">
        {options.map(opt => (
          <button
            key={opt}
            type="button"
            onClick={() => onChange(opt)}
            className={cn(
              "px-4 py-2 rounded-xl text-sm font-medium border-2 transition-all duration-200",
              value === opt
                ? "border-[var(--mc-brown)] bg-[var(--mc-brown)]/10 text-[var(--mc-brown)] shadow-sm"
                : "border-[var(--mc-brown)]/15 bg-white/60 text-[var(--mc-brown)]/60 hover:border-[var(--mc-brown)]/40 hover:bg-white/80"
            )}
          >
            {opt}
          </button>
        ))}
      </div>
    </div>
  );
}



function DesignPrefTile({
  label, options, value, onChange, icon: Icon,
}: { label: string; options: string[]; value: string; onChange: (v: string) => void; icon: typeof Crown }) {
  return (
    <div className="group relative rounded-2xl bg-white/55 border border-[var(--mc-brown)]/25 p-4 shadow-[0_8px_24px_-16px_rgba(40,30,20,0.35)] hover:shadow-[0_18px_40px_-22px_rgba(40,30,20,0.5)] hover:border-[var(--mc-brown)]/45 transition-all flex flex-col">
      <p className="text-center text-[13px] font-semibold text-[var(--mc-brown)] tracking-tight">{label}</p>
      <div className="my-3 mx-auto flex h-20 w-20 items-center justify-center rounded-xl bg-gradient-to-br from-[var(--mc-gold)]/15 to-[var(--mc-brown)]/8 border-2 border-[var(--mc-gold)]/40 ring-1 ring-inset ring-[var(--mc-brown)]/10 shadow-[inset_0_1px_0_rgba(255,255,255,0.6),0_2px_8px_-4px_rgba(40,30,20,0.25)]">
        <Icon className="h-9 w-9 text-[var(--mc-brown)]/55" strokeWidth={1.4} />
      </div>
      <div className="relative mt-auto" style={{ accentColor: "var(--mc-brown)", colorScheme: "light" }}>
        <select
          value={value}
          onChange={(e) => onChange(e.target.value)}
          style={{ accentColor: "var(--mc-brown)", colorScheme: "light" }}
          className="w-full appearance-none bg-transparent text-center text-[13px] font-semibold text-[var(--mc-brown)] py-1.5 pr-5 cursor-pointer focus:outline-none focus:ring-0 focus-visible:outline-none [&>option]:bg-white [&>option]:text-[var(--mc-brown)] [&>option:checked]:bg-[var(--mc-gold)]/30"
        >
          {options.map(o => <option key={o} value={o}>{o}</option>)}
        </select>
        <ChevronDown className="pointer-events-none absolute right-1 top-1/2 -translate-y-1/2 h-3.5 w-3.5 text-[var(--mc-brown)]/60" />
      </div>
    </div>
  );
}

function MasterCrownApp() {
  const [category, setCategory] = useState<CaseCategory>("crowns");
  const [scanFile, setScanFile] = useState<File | null>(null);
  const [notes, setNotes] = useState("");
  const [submitting, setSubmitting] = useState(false);
  const [workflow, setWorkflow] = useState<WorkflowState>("configure");
  const [user, setUser] = useState<{ name: string; email: string } | null>(null);
  const [balance, setBalance] = useState<number>(0);
  const [tokenPulse, setTokenPulse] = useState<number>(0);
  const [topUpOpen, setTopUpOpen] = useState(false);
  const handleTopUp = () => setTopUpOpen(true);

  // Demo preview only — no persisted session or token balance.
  // Real auth + wallet must be wired through Lovable Cloud before going live.

  const [email, setEmail] = useState("");
  const [doctorName, setDoctorName] = useState("");
  const [patientRef, setPatientRef] = useState("");
  const [phone, setPhone] = useState("");
  const [contactMethod, setContactMethod] = useState<"email" | "sms" | "both">("email");
  const [selectedTeeth, setSelectedTeeth] = useState<number[]>([]);
  const [centralLength, setCentralLength] = useState("");
  const [canineLength, setCanineLength] = useState("");
  const [style, setStyle] = useState<StyleOption>("Regular");
  const [contactShape, setContactShape] = useState<ContactShape>("Regular");
  const [prefs, setPrefs] = useState<Record<CaseCategory, Record<string, string>>>(() => {
    const seed = {} as Record<CaseCategory, Record<string, string>>;
    (Object.keys(PREFS) as CaseCategory[]).forEach(cat => {
      seed[cat] = Object.fromEntries(PREFS[cat].fields.map(f => [f.key, f.options[0]]));
    });
    return seed;
  });
  const setPref = (cat: CaseCategory, key: string, value: string) =>
    setPrefs(p => ({ ...p, [cat]: { ...p[cat], [key]: value } }));
  const activeIcon = CATEGORIES.find(c => c.id === category)?.icon ?? Crown;

  const handleToothClick = useCallback((num: number) => {
    setSelectedTeeth(prev => prev.includes(num) ? prev.filter(t => t !== num) : [...prev, num]);
  }, []);

  const unitPrice = category === "bridges" ? PRICE_BRIDGE : PRICE_CROWN;
  const totalPrice = selectedTeeth.length * unitPrice;

  const handleSubmit = async () => {
    if (!doctorName.trim()) return toast.error("Please enter the doctor's name.");
    if (!patientRef.trim()) return toast.error("Please enter a patient reference (initials or chart #).");
    if (!email) return toast.error("Please enter your return email.");
    if ((contactMethod === "sms" || contactMethod === "both") && !phone.trim()) {
      return toast.error("Please enter a mobile number for SMS approval.");
    }
    if (selectedTeeth.length === 0) return toast.error("Please select at least one tooth.");
    if (!scanFile) return toast.error("Please upload your scan file.");

    setSubmitting(true);
