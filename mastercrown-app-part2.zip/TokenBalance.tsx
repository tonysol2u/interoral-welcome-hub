import { useEffect, useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { cn } from "@/lib/utils";
import tokenCoin from "@/assets/icons/badge-tooth.png";

interface TokenBalanceProps {
  balance: number;
  onTopUp?: () => void;
  /** Increment a number to trigger the "fueled" glow animation */
  pulseKey?: number;
  size?: "sm" | "md" | "lg";
  showTopUp?: boolean;
  className?: string;
  label?: string;
}

const sizeMap = {
  sm: { coin: "h-5 w-5", text: "text-[12px]", padding: "px-3 py-1.5" },
  md: { coin: "h-7 w-7", text: "text-[14px]", padding: "px-4 py-2" },
  lg: { coin: "h-10 w-10", text: "text-[20px]", padding: "px-5 py-3" },
};

/**
 * Universal token balance pill — gold coin + numerical balance.
 * Used across MasterCrown, and the user dashboard.
 * Tokens are universal "fuel" pulled from the central wallet API.
 */
export function TokenBalance({
  balance,
  onTopUp,
  pulseKey = 0,
  size = "md",
  showTopUp = true,
  className,
  label = "MASTERCREDIT BALANCE",
}: TokenBalanceProps) {
  const s = sizeMap[size];
  const [glow, setGlow] = useState(false);

  useEffect(() => {
    if (pulseKey === 0) return;
    setGlow(true);
    const t = setTimeout(() => setGlow(false), 1400);
    return () => clearTimeout(t);
  }, [pulseKey]);

  return (
    <div
      className={cn(
        "inline-flex items-center gap-2 rounded-full border border-[#fde047]/60 bg-gradient-to-b from-[#0b1437] to-[#050a1f] backdrop-blur-md shadow-[0_10px_30px_-10px_rgba(0,0,0,0.6),inset_0_1px_0_0_rgba(253,224,71,0.25)]",
        s.padding,
        className,
      )}
    >
      <div className="relative">
        <motion.img
          src={tokenCoin}
          alt="MasterCredit"
          className={cn(s.coin, "drop-shadow-[0_2px_8px_rgba(253,224,71,0.55)]")}
          animate={glow ? { scale: [1, 1.18, 1], rotate: [0, -8, 6, 0] } : { scale: 1 }}
          transition={{ duration: 1.1, ease: "easeInOut" }}
        />
        <AnimatePresence>
          {glow && (
            <motion.span
              key="glow"
              initial={{ opacity: 0, scale: 0.6 }}
              animate={{ opacity: [0, 0.95, 0], scale: [0.6, 1.8, 2.4] }}
              exit={{ opacity: 0 }}
              transition={{ duration: 1.2, ease: "easeOut" }}
              className="pointer-events-none absolute inset-0 rounded-full"
              style={{
                background:
                  "radial-gradient(circle, rgba(253,224,71,0.7) 0%, rgba(253,224,71,0) 70%)",
              }}
            />
          )}
        </AnimatePresence>
      </div>

      <div className="flex items-baseline gap-1.5">
        <motion.span
          key={balance}
          initial={{ opacity: 0, y: -4 }}
          animate={{ opacity: 1, y: 0 }}
          className={cn("font-bold tracking-tight text-[#fde047] tabular-nums drop-shadow-[0_1px_0_rgba(0,0,0,0.4)]", s.text)}
        >
          {balance}
        </motion.span>
        <span className="font-mono-tech text-[9px] uppercase tracking-[0.18em] text-[#fde047]/70">
          {label}
        </span>
      </div>

      {showTopUp && onTopUp && (
        <button
          type="button"
          onClick={onTopUp}
          className="ml-1 rounded-full border border-[#fde047]/50 bg-[#fde047]/10 px-2.5 py-1 font-mono-tech text-[9px] font-bold uppercase tracking-[0.18em] text-[#fde047] transition-colors hover:bg-[#fde047] hover:text-[#0b1437]"
        >
          Purchase
        </button>
      )}
    </div>
  );
}
