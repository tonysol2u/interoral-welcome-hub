Part 2 of 3 — MasterCrown App
Contains:
- mastercrown-app.part2.tsx (lines 251-500)
- TokenBalance.tsx (src/components/mastercrown/)
