    setWorkflow("processing");

    setTimeout(() => {
      setSubmitting(false);
      setWorkflow("review");
      // Demo: simulate token consumption visually only (no persistence).
      const cost = Math.max(1, selectedTeeth.length);
      setBalance(b => Math.max(0, b - cost));
      setTokenPulse(p => p + 1);
      toast.info("Design ready for your review!");
    }, 4000);
  };

  const handleApprove = () => {
    toast.success(`Design approved! ${selectedTeeth.length} unit(s) — $${totalPrice}. STL files sent to ${email}.`);
    setWorkflow("configure");
    setSelectedTeeth([]);
    setScanFile(null);
  };

  const handleReject = () => {
    toast("Design rejected. No charge applied.");
    setWorkflow("configure");
  };

  return (
    <main
      className="relative min-h-screen overflow-x-clip"
      style={{
        background:
          "radial-gradient(ellipse 40% 32% at 50% 28%, oklch(0.9 0.02 248) 0%, oklch(0.82 0.03 250) 55%, transparent 100%), radial-gradient(ellipse at 50% 50%, oklch(0.7 0.04 250) 0%, oklch(0.55 0.05 252) 70%, oklch(0.45 0.05 253) 100%)",
      }}
    >
      {/* Texture layers — same vibe as the home page */}
      <div aria-hidden className="pointer-events-none fixed inset-0 z-0" style={{ backgroundImage: `url(${brokenChain})`, backgroundSize: "cover", backgroundPosition: "center", opacity: 0.18, mixBlendMode: "screen" }} />
      <div aria-hidden className="pointer-events-none fixed inset-0 z-0" style={{ backgroundImage: `url(${cubesPattern})`, backgroundRepeat: "repeat", opacity: 0.25, mixBlendMode: "overlay" }} />
      <div aria-hidden className="pointer-events-none fixed inset-0 z-0" style={{ backgroundImage: `url(${triangleMesh})`, backgroundSize: "cover", backgroundPosition: "center", opacity: 0.3, mixBlendMode: "overlay" }} />
      <div aria-hidden className="pointer-events-none fixed inset-0 z-0" style={{ background: "radial-gradient(ellipse at center, transparent 40%, rgba(0,0,0,0.45) 100%)" }} />

      {/* Top-right utilities */}
      <div className="fixed top-4 right-4 z-40 flex items-center gap-2">
        <TokenBalance
          balance={balance}
          onTopUp={handleTopUp}
          pulseKey={tokenPulse}
          size="sm"
          label={user ? `${(user.name || "").toUpperCase()} · MASTERCREDITS` : "MASTERCREDITS"}
        />
        <Link
          to="/"
          className="flex items-center gap-2 border border-[var(--mc-line)] bg-white/85 px-4 py-2 backdrop-blur-md shadow-[0_10px_30px_-10px_rgba(40,30,20,0.4)] hover:bg-white transition-colors"
          style={{ borderRadius: "999px" }}
        >
          <span className="mc-track font-mono-tech text-[10px] text-[var(--mc-brown)]">
            ← BACK TO HOME
          </span>
        </Link>
      </div>

      <div className="relative z-10 pt-20 pb-24 px-6 max-w-6xl mx-auto">
        {/* Header */}
        <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} className="text-center mb-8">
          <div className="inline-flex items-center gap-2 px-4 py-1.5 rounded-full bg-[var(--mc-gold)]/15 border border-[var(--mc-gold)]/40 text-[var(--mc-brown)] text-sm font-medium mb-4">
            <Sparkles className="w-4 h-4 text-[var(--mc-gold)]" />
            Express AI Design
          </div>
          <div className="flex items-center justify-center gap-4">
            <img src={mcLogo} alt="MasterCrown.ai" className="h-16 w-16 md:h-20 md:w-20 rounded-full drop-shadow-[0_6px_18px_rgba(0,0,0,0.45)]" />
            <h1 className="font-display font-light tracking-[-0.04em] text-[var(--mc-brown)]" style={{ fontSize: "clamp(28px, 5vw, 56px)", lineHeight: 1 }}>
              MasterCrown<span>.ai</span>
            </h1>
          </div>
          <p className="text-[var(--mc-brown)]/70 text-sm font-medium mt-3">Precision STL Files — Under 5 Minutes</p>
          <p className="text-[var(--mc-brown)]/60 text-[12px] md:text-[13px] mt-2 max-w-2xl mx-auto leading-relaxed">
            MasterCrown designs are powered by <MasterCoin />—the secure digital currency of the MasterSTL.ai ecosystem.
          </p>
          <div className="flex flex-nowrap items-center justify-center gap-2 mt-4 overflow-x-auto">
            {[
              { icon: Clock, label: "Under 5 min" },
              { icon: Zap, label: "AI-Powered" },
              { icon: Shield, label: "HIPAA Secure" },
            ].map(p => (
              <div key={p.label} className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full border border-[var(--mc-gold)]/40 bg-white/60 text-[11px] font-medium text-[var(--mc-brown)] whitespace-nowrap shrink-0">
                <p.icon className="w-3 h-3 text-[var(--mc-gold)]" />
                {p.label}
              </div>
            ))}
          </div>
        </motion.div>

        {/* Sovereign Vault — MasterCoin currency strip */}
        <motion.div
          initial={{ opacity: 0, y: 15 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.03 }}
          className="mb-6 rounded-2xl border border-[#fde047]/40 bg-gradient-to-br from-[#0b1437] via-[#0b1437] to-[#050a1f] px-4 py-3 md:px-5 md:py-4 shadow-[0_30px_60px_-30px_rgba(0,0,0,0.7),inset_0_1px_0_0_rgba(253,224,71,0.18)] relative overflow-hidden"
        >
          <div aria-hidden className="pointer-events-none absolute inset-0 opacity-[0.08]" style={{ backgroundImage: "radial-gradient(circle at 20% 0%, #fde047 0%, transparent 40%), radial-gradient(circle at 90% 100%, #fde047 0%, transparent 50%)" }} />
          <div className="relative flex flex-col sm:flex-row sm:items-center gap-3 sm:gap-4">
            <div className="flex items-center gap-3 min-w-0">
              <motion.img
                src={toothCoin}
                alt="MasterCredit"
                className="h-12 w-12 shrink-0 drop-shadow-[0_4px_14px_rgba(253,224,71,0.55)]"
                animate={tokenPulse > 0 ? { scale: [1, 1.18, 1], rotate: [0, -8, 0] } : {}}
                transition={{ duration: 1 }}
              />
              <div className="min-w-0">
                <p className="text-[10px] uppercase tracking-[0.24em] text-[#fde047]/70 font-bold">
                  MasterSTL.ai Vault
                </p>
                <p className="text-sm font-semibold text-white leading-tight">
                  Your <MasterCoin plural /> — the premium currency of the platform.
                </p>
              </div>
            </div>

            <div className="sm:ml-auto shrink-0">
              <TokenBalance
                balance={balance}
                onTopUp={handleTopUp}
                pulseKey={tokenPulse}
                size="md"
                label="BALANCE"
              />
            </div>
          </div>
          <p className="relative mt-2 text-[11px] text-[#fde047]/60 leading-relaxed">
            One vault, one credit. <MasterCoin plural className="text-[11px]" /> are universal across MasterSTL.ai and MasterCrown — exchange them for any design, anywhere.
          </p>
        </motion.div>

        {/* Category tabs — 3 columns × 2 rows */}
        <motion.div initial={{ opacity: 0, y: 15 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.05 }} className="grid grid-cols-2 md:grid-cols-3 gap-3 mb-6">
          {CATEGORIES.map(cat => (
            <button
              key={cat.id}
              onClick={() => { if (workflow === "configure" && cat.enabled) setCategory(cat.id); }}
              disabled={workflow !== "configure" || !cat.enabled}
              className={cn(
                "relative flex items-center gap-3 px-4 py-3 rounded-2xl border-2 transition-all duration-200",
                workflow === "configure" && cat.enabled ? "cursor-pointer" : "cursor-not-allowed opacity-60",
                category === cat.id
                  ? "border-[var(--mc-brown)] bg-white/70 shadow-md"
                  : "border-[var(--mc-brown)]/15 bg-white/40 hover:border-[var(--mc-brown)]/30"
              )}
            >
              <cat.icon className={cn("w-5 h-5 shrink-0", category === cat.id ? "text-[var(--mc-brown)]" : "text-[var(--mc-brown)]/40")} />
              <div className="text-left min-w-0">
                <p className={cn("text-[13px] font-semibold leading-tight", category === cat.id ? "text-[var(--mc-brown)]" : "text-[var(--mc-brown)]/60")}>{cat.label}</p>
                <p className="text-[10px] text-[var(--mc-brown)]/50">{cat.price}</p>
              </div>
              {!cat.enabled && <Lock className="w-3 h-3 text-[var(--mc-brown)]/40 absolute top-2 right-2" />}
            </button>
          ))}
        </motion.div>

        {/* Main card */}
        <div className={cn(
          "grid gap-5",
          (category === "crowns" || category === "bridges" || category === "copings") && workflow === "configure" ? "lg:grid-cols-[300px_1fr] lg:grid-rows-[auto_1fr] lg:items-stretch" : "grid-cols-1"
        )}>
          {/* LEFT — De-identified case info (outside the main tile) */}
          {(category === "crowns" || category === "bridges" || category === "copings") && workflow === "configure" && (
            <aside className="lg:col-start-1 lg:row-start-1 space-y-3 rounded-3xl bg-white/55 backdrop-blur-[14px] border border-[var(--mc-brown)]/15 p-5 h-fit shadow-[0_20px_40px_-25px_rgba(40,30,20,0.4)]">
              <div className="flex items-center gap-2 pb-2 border-b border-[var(--mc-brown)]/10">
                <Shield className="w-4 h-4 text-[var(--mc-gold)]" />
                <h3 className="text-[12px] font-bold uppercase tracking-widest text-[var(--mc-brown)]">
                  Case Details
                </h3>
              </div>
              <p className="text-[10.5px] leading-snug text-[var(--mc-brown)]/65">
                All patient information is automatically de-identified before reaching our AI. Use a reference name or chart number — no PHI is stored.
              </p>

              <div className="space-y-1">
                <Label className="text-[var(--mc-brown)] text-[11px] font-semibold">Doctor's Name *</Label>
                <Input placeholder="Dr. Jane Smith" value={doctorName} onChange={e => setDoctorName(e.target.value)}
                  className="bg-white/80 border-[var(--mc-brown)]/15 text-[var(--mc-brown)] text-xs h-8 placeholder:text-[var(--mc-brown)]/30" />
              </div>
              <div className="space-y-1">
                <Label className="text-[var(--mc-brown)] text-[11px] font-semibold">Patient Reference *</Label>
                <Input placeholder="Initials or chart # (e.g. J.D. / 4421)" value={patientRef} onChange={e => setPatientRef(e.target.value)}
                  className="bg-white/80 border-[var(--mc-brown)]/15 text-[var(--mc-brown)] text-xs h-8 placeholder:text-[var(--mc-brown)]/30" />
                <p className="text-[9.5px] text-[var(--mc-brown)]/50 leading-tight">Do not enter full patient name.</p>
              </div>
              <div className="space-y-1">
                <Label className="text-[var(--mc-brown)] text-[11px] font-semibold">Return Email *</Label>
                <Input type="email" placeholder="doctor@practice.com" value={email} onChange={e => setEmail(e.target.value)}
                  className="bg-white/80 border-[var(--mc-brown)]/15 text-[var(--mc-brown)] text-xs h-8 placeholder:text-[var(--mc-brown)]/30" />
              </div>
              <div className="space-y-1">
                <Label className="text-[var(--mc-brown)] text-[11px] font-semibold">Mobile (for SMS)</Label>
                <Input type="tel" placeholder="+1 (555) 123-4567" value={phone} onChange={e => setPhone(e.target.value)}
                  className="bg-white/80 border-[var(--mc-brown)]/15 text-[var(--mc-brown)] text-xs h-8 placeholder:text-[var(--mc-brown)]/30" />
              </div>
              <div className="space-y-1.5">
                <Label className="text-[var(--mc-brown)] text-[11px] font-semibold">Approve Via</Label>
                <div className="grid grid-cols-3 gap-1.5">
                  {(["email", "sms", "both"] as const).map(m => (
                    <button key={m} type="button" onClick={() => setContactMethod(m)}
                      className={cn(
                        "px-2 py-1.5 rounded-lg border text-[10px] font-semibold uppercase tracking-wider transition-all",
                        contactMethod === m
                          ? "bg-[var(--mc-brown)] text-white border-[var(--mc-brown)]"
                          : "bg-white/70 text-[var(--mc-brown)]/70 border-[var(--mc-brown)]/15 hover:border-[var(--mc-brown)]/40"
                      )}>
                      {m === "both" ? "Both" : m.toUpperCase()}
                    </button>
                  ))}
                </div>
              </div>
              <div className="rounded-lg bg-[var(--mc-gold)]/10 border border-[var(--mc-gold)]/30 p-2">
                <p className="text-[9.5px] text-[var(--mc-brown)]/75 leading-snug">
                  🔒 HIPAA-aligned: identifiers stripped from scan headers before processing.
                </p>
              </div>
            </aside>
          )}

          {/* LEFT (under Case Details) — Sovereign Vault mini-tile */}
          {(category === "crowns" || category === "bridges" || category === "copings") && workflow === "configure" && (
            <aside className="lg:col-start-1 lg:row-start-2 lg:self-stretch flex flex-col rounded-3xl bg-gradient-to-br from-[#0b1437] via-[#0b1437] to-[#050a1f] border border-[#fde047]/40 p-5 shadow-[0_30px_60px_-30px_rgba(0,0,0,0.7),inset_0_1px_0_0_rgba(253,224,71,0.18)] space-y-5 relative overflow-hidden">
              <div aria-hidden className="pointer-events-none absolute inset-0 opacity-[0.08]" style={{ backgroundImage: "radial-gradient(circle at 100% 0%, #fde047 0%, transparent 50%)" }} />
              <div className="relative flex items-center gap-3 pb-3 border-b border-[#fde047]/25">
                <motion.img
                  src={toothCoin}
                  alt="MasterCredit"
                  className="h-12 w-12 shrink-0 drop-shadow-[0_3px_12px_rgba(253,224,71,0.55)]"
                  animate={tokenPulse > 0 ? { scale: [1, 1.15, 1], rotate: [0, -6, 0] } : {}}
                  transition={{ duration: 1 }}
                />
                <div className="min-w-0 flex-1">
                  <p className="text-[10px] uppercase tracking-[0.22em] text-[#fde047]/70 font-bold">
                    Your <MasterCoin plural className="text-[10px]" /> Balance
                  </p>
                  <p className="text-[24px] font-bold text-[#fde047] leading-tight tabular-nums drop-shadow-[0_1px_0_rgba(0,0,0,0.4)]">
                    {balance} <span className="text-[10.5px] font-medium text-[#fde047]/60 uppercase tracking-widest">MasterCredit Balance</span>
                  </p>
                </div>
              </div>

              <p className="relative text-[10.5px] leading-snug text-white/70">
                1 <MasterCoin className="text-[10.5px]" /> = $1. Premium currency — exchange for any design across the platform.
              </p>

              <div className="relative rounded-xl border border-[#fde047]/25 bg-white/5 backdrop-blur-sm p-3 text-center">
                <p className="mc-track font-mono-tech text-[9.5px] uppercase tracking-[0.22em] text-[#fde047]/70">
                  <MasterCoin plural className="text-[9.5px]" /> Packs
                </p>
